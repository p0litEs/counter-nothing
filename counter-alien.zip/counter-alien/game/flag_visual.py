"""The flag's in-world look (original design): a slim mast with a signal-orange
pennant block and a beacon cap. Carried flags ride on the carrier's back,
dropped ones stand where they fell, planted ones blink and show a ground ring.
"""
from __future__ import annotations

import math

from ursina import Entity, color, time
from ursina.shaders import lit_with_shadows_shader, unlit_shader

from game.rounds import FlagState

ORANGE = color.rgba(0.97, 0.55, 0.12, 1)
MAST = color.rgba(0.85, 0.86, 0.88, 1)


class FlagVisual(Entity):
    def __init__(self, rounds):
        super().__init__(name="flag_visual")
        self.rm = rounds
        sh = lit_with_shadows_shader
        self.rig = Entity(parent=self)
        Entity(parent=self.rig, model="cube", position=(0, 0.9, 0), scale=(0.05, 1.8, 0.05), color=MAST, shader=sh)
        Entity(parent=self.rig, model="cube", position=(0.24, 1.55, 0), scale=(0.44, 0.3, 0.03), color=ORANGE, shader=sh)
        Entity(parent=self.rig, model="cube", position=(0.14, 1.32, 0), scale=(0.24, 0.16, 0.03), color=ORANGE, shader=sh)
        self.beacon = Entity(parent=self.rig, model="sphere", position=(0, 1.86, 0), scale=0.14,
                             color=color.rgba(1, 0.9, 0.4, 1), shader=unlit_shader)
        self.ring = Entity(parent=self, model="circle", rotation_x=90, y=0.03, scale=4.0,
                           color=color.rgba(0.97, 0.55, 0.12, 0.25), shader=unlit_shader)
        self.t = 0.0

    def update(self):
        f = self.rm.flag
        self.t += time.dt
        carrier = f.carrier if f.state == FlagState.CARRIED else None
        if carrier is not None and not getattr(carrier, "is_bot", False):
            self.visible = False                    # the human carrier doesn't see their own flag
            return
        self.visible = True
        x, y, z = f.pos
        self.ring.enabled = f.state == FlagState.PLANTED
        if carrier is not None:
            # on the carrier's back, leaning slightly
            yaw = math.radians(getattr(carrier, "yaw", 0.0))
            self.position = (x - math.sin(yaw) * 0.3, y + 0.2, z - math.cos(yaw) * 0.3)
            self.rig.rotation = (12, getattr(carrier, "yaw", 0.0), 0)
            self.rig.scale = 0.8
        else:
            self.position = (x, y, z)
            self.rig.rotation = (0, self.t * 40 if f.state == FlagState.DROPPED else 0, 0)
            self.rig.scale = 1.0
        blink = f.state == FlagState.PLANTED and (self.t * 2.5) % 1.0 < 0.5
        self.beacon.color = color.rgba(1, 0.25, 0.2, 1) if blink else color.rgba(1, 0.9, 0.4, 1)
