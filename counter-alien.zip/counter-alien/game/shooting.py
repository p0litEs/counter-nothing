"""Shot resolution shared by the player and bots.

Takes an aim (yaw/pitch), applies the weapon's spread, ray casts through the
CombatWorld and applies damage. Visuals go through an Effects object.
"""
from __future__ import annotations

from dataclasses import dataclass

from game.combat import BODY, CombatWorld
from game.weapons import WeaponDefinition, apply_spread, direction


@dataclass
class ShotOutcome:
    hit_target: object | None = None
    headshot: bool = False
    killed: bool = False
    damage: float = 0.0


def fire_hitscan(combat: CombatWorld, effects, shooter, wd: WeaponDefinition,
                 origin, yaw: float, pitch: float, spread: float, rng,
                 center_bias: float, muzzle, tracer_color=None) -> ShotOutcome:
    yaw, pitch = apply_spread(yaw, pitch, spread, rng, center_bias)
    d = direction(yaw, pitch)
    hit = combat.raycast(origin, d, wd.range, ignore=shooter)
    end = hit.point if hit else tuple(origin[i] + d[i] * wd.range for i in range(3))
    if effects:
        if tracer_color is not None:
            effects.tracer(muzzle, end, tracer_color)
        else:
            effects.tracer(muzzle, end)
    out = ShotOutcome()
    if hit is None:
        return out
    if hit.target is None:
        if effects:
            effects.impact(hit.point)
        return out
    if combat.can_damage(shooter, hit.target):
        dmg, killed = combat.apply_hit(shooter, hit.target, wd.damage, hit.distance,
                                       wd.falloff_per_10m, hit.part, wd.name)
        out = ShotOutcome(hit.target, hit.part == "head", killed, dmg)
    return out


def melee_swing(combat: CombatWorld, shooter, wd: WeaponDefinition, origin,
                yaw: float, pitch: float) -> ShotOutcome:
    """Five short rays fanned across melee_arc; the first enemy touched is hit once.
    Melee ignores the headshot multiplier (always counts as a body hit)."""
    n = 5
    for order in (2, 1, 3, 0, 4):                     # centre ray first, then outward
        off = -wd.melee_arc / 2 + wd.melee_arc * order / (n - 1)
        hit = combat.raycast(origin, direction(yaw + off, pitch), wd.range, ignore=shooter)
        if hit and hit.target is not None and combat.can_damage(shooter, hit.target):
            dmg, killed = combat.apply_hit(shooter, hit.target, wd.damage, 0.0, 1.0, BODY, wd.name)
            return ShotOutcome(hit.target, False, killed, dmg)
    return ShotOutcome()
