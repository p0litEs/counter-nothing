"""First-person weapon placeholders built from boxes (original shapes).

The whole rig is built at normal size and then scaled down 0.3x closer to the
camera. Perspective makes it look identical, but it never pokes into walls
(it stays inside the player's 0.3 m collision radius).
"""
from __future__ import annotations

import math

from ursina import Entity, Vec3, camera, color, time
from ursina.shaders import unlit_shader

BODY = color.rgba(0.20, 0.22, 0.26, 1)
ACCENT = color.rgba(0.95, 0.55, 0.15, 1)      # signal orange, matches map trim
GRIP = color.rgba(0.32, 0.30, 0.27, 1)
BLADE = color.rgba(0.78, 0.80, 0.84, 1)


def _part(parent, pos, scale, col):
    return Entity(parent=parent, model="cube", position=pos, scale=scale, color=col)


class ViewModel(Entity):
    def __init__(self):
        super().__init__(parent=camera, scale=0.3, position=(0, 0, 0))
        self.rigs = {}
        self.muzzles = {}

        # Slot 1: RK-9 Rifle — long receiver, angular stock, orange rail stripe
        r = Entity(parent=self, position=(0.34, -0.33, 0.78))
        _part(r, (0, 0, 0.05), (0.09, 0.11, 0.62), BODY)
        _part(r, (0, 0.065, 0.05), (0.03, 0.02, 0.5), ACCENT)
        _part(r, (0, -0.02, 0.48), (0.05, 0.05, 0.28), BODY)           # barrel shroud
        _part(r, (0, -0.10, 0.10), (0.06, 0.16, 0.07), GRIP)            # magazine
        _part(r, (0, -0.06, -0.33), (0.07, 0.13, 0.18), GRIP)           # stock
        self.rigs[1] = r
        self.muzzles[1] = Entity(parent=r, position=(0, -0.02, 0.66))

        # Slot 2: SD-4 Sidearm — compact slide + grip
        p = Entity(parent=self, position=(0.27, -0.27, 0.66))
        _part(p, (0, 0.02, 0.02), (0.06, 0.07, 0.26), BODY)
        _part(p, (0, 0.06, 0.02), (0.02, 0.012, 0.2), ACCENT)
        _part(p, (0, -0.07, -0.06), (0.05, 0.14, 0.07), GRIP)
        self.rigs[2] = p
        self.muzzles[2] = Entity(parent=p, position=(0, 0.02, 0.17))

        # Slot 3: Field Knife — straight blade, wrapped handle
        k = Entity(parent=self, position=(0.30, -0.27, 0.62), rotation=(10, -12, -20))
        _part(k, (0, 0, 0.12), (0.018, 0.05, 0.24), BLADE)
        _part(k, (0, 0, -0.03), (0.03, 0.045, 0.06), ACCENT)            # guard
        _part(k, (0, 0, -0.11), (0.03, 0.04, 0.11), GRIP)
        self.rigs[3] = k
        self.muzzles[3] = Entity(parent=k, position=(0, 0, 0.25))

        self.flash = Entity(parent=self, model="quad", scale=0.09, color=color.rgba(1, 0.72, 0.25, 1),
                            shader=unlit_shader, rotation_z=45, enabled=False)
        self.home = {s: Vec3(e.position) for s, e in self.rigs.items()}
        self.home_rot = {s: Vec3(e.rotation) for s, e in self.rigs.items()}
        self.active = 1
        self.kick_amount = 0.0
        self.swing_t = 1.0
        self.deploy_t = 1.0
        self.flash_t = 0.0
        self.bob_t = 0.0
        self.reload_t = 1.0
        self.inspect_t = 1.0
        glove = color.rgb(102, 112, 88)
        for rig in self.rigs.values():
            _part(rig, (-0.19, -0.17, 0.03), (0.10, 0.11, 0.34), color.rgb(72, 83, 78))
            _part(rig, (0.19, -0.17, -0.07), (0.10, 0.11, 0.30), color.rgb(72, 83, 78))
            _part(rig, (-0.12, -0.10, 0.20), (0.13, 0.075, 0.13), glove)
            _part(rig, (0.10, -0.105, 0.095), (0.13, 0.075, 0.13), glove)
            for index in range(3):
                offset = (index - 1) * 0.035
                _part(rig, (-0.12 + offset, -0.12, 0.28),
                      (0.025, 0.035, 0.09), glove)
                _part(rig, (0.10 + offset, -0.12, 0.17),
                      (0.025, 0.035, 0.08), glove)
        self.show(1, 0.3)

    def show(self, slot: int, deploy_time: float):
        self.active = slot
        for s, e in self.rigs.items():
            e.enabled = s == slot
        self.deploy_t = 0.0
        self._deploy_len = max(deploy_time, 1e-3)

    def kick(self):
        self.kick_amount = 1.0
        self.flash.enabled = True
        self.flash.world_position = self.muzzles[self.active].world_position
        self.flash_t = 0.035

    def swing(self):
        self.swing_t = 0.0

    def reload(self):
        self.reload_t = 0.0

    def inspect(self):
        self.inspect_t = 0.0

    def muzzle_world(self):
        return tuple(self.muzzles[self.active].world_position)

    def update_pose(self, move_speed: float):
        dt = time.dt
        rig = self.rigs[self.active]
        home = self.home[self.active]
        self.deploy_t = min(1.0, self.deploy_t + dt / self._deploy_len)
        self.kick_amount *= math.exp(-18 * dt)
        self.bob_t += dt * (2.0 + move_speed * 1.4)
        bob = min(move_speed / 6.0, 1.0)
        rig.position = home + Vec3(math.sin(self.bob_t) * 0.012 * bob,
                                   -abs(math.cos(self.bob_t)) * 0.012 * bob - (1 - self.deploy_t) * 0.35,
                                   -0.07 * self.kick_amount)
        rot = Vec3(self.home_rot[self.active])
        rot.x -= 6 * self.kick_amount
        if self.reload_t < 1.0:
            self.reload_t = min(1.0, self.reload_t + dt / 0.75)
            reload_phase = math.sin(self.reload_t * math.pi)
            rig.position += Vec3(0, -0.12 * reload_phase, 0)
        if self.inspect_t < 1.0:
            self.inspect_t = min(1.0, self.inspect_t + dt / 0.55)
            inspect_phase = math.sin(self.inspect_t * math.pi)
            rot += Vec3(0, 0, 12 * inspect_phase)
        if self.active == 3 and self.swing_t < 1.0:
            self.swing_t = min(1.0, self.swing_t + dt / 0.28)
            s = math.sin(self.swing_t * math.pi)
            rot += Vec3(25 * s, -55 * s, 20 * s)
        rig.rotation = rot
        if self.flash_t > 0:
            self.flash_t -= dt
            if self.flash_t <= 0:
                self.flash.enabled = False
