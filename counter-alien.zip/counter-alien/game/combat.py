"""Engine-independent combat: ray casts, hitboxes, the damage model.

Anything that can be shot implements the Combatant protocol below (Player
and Bot both do). Ray casts test the map's collision boxes and every living
combatant's hitboxes with a slab test — no engine colliders needed, so this
module is unit-testable headless.

Damage model:
    dmg = base * falloff_per_10m ** (distance / 10)
    head hit:  dmg *= helmet_headshot_multiplier if helmet else headshot_multiplier
    armor absorbs armor_absorption of the damage when the hit part is covered
    (body: any armor; head: only with a helmet); armor loses absorbed * armor_wear.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Protocol

from game.physics import AABB, CollisionWorld

HEAD = "head"
BODY = "body"
HEAD_SIZE = 0.34        # head box edge length (m)


class Combatant(Protocol):
    team: str
    display_name: str
    alive: bool
    vitals: "Vitals"

    def hitboxes(self) -> list[tuple[AABB, str]]: ...
    def eye_position(self) -> tuple[float, float, float]: ...
    def on_damaged(self, attacker, health_damage: float) -> None: ...
    def on_killed(self, attacker) -> None: ...


def standard_hitboxes(x: float, y: float, z: float, height: float, radius: float):
    """Body box from the feet to the neck, a smaller head box on top."""
    neck = y + height - HEAD_SIZE
    h = HEAD_SIZE / 2
    return [
        (AABB(x - h, neck, z - h, x + h, y + height, z + h), HEAD),
        (AABB(x - radius, y, z - radius, x + radius, neck, z + radius), BODY),
    ]


# --------------------------------------------------------------------------- #
#  Damage
# --------------------------------------------------------------------------- #
@dataclass
class Vitals:
    health: float
    armor: float
    helmet: bool
    max_health: float = 100.0
    max_armor: float = 100.0

    @property
    def dead(self) -> bool:
        return self.health <= 0


def compute_damage(base: float, distance: float, falloff_per_10m: float, part: str,
                   armor: float, helmet: bool, rules) -> tuple[float, float]:
    """Returns (health_damage, armor_lost)."""
    dmg = base * (falloff_per_10m ** (distance / 10.0))
    if part == HEAD:
        dmg *= rules.helmet_headshot_multiplier if helmet else rules.headshot_multiplier
    covered = armor > 0 and (part == BODY or helmet)
    if not covered:
        return dmg, 0.0
    absorbed = dmg * rules.armor_absorption
    armor_lost = absorbed * rules.armor_wear
    if armor_lost > armor:                       # armor breaks: absorbs only what it had
        absorbed = armor / rules.armor_wear
        armor_lost = armor
    return dmg - absorbed, armor_lost


# --------------------------------------------------------------------------- #
#  Ray casting
# --------------------------------------------------------------------------- #
def ray_aabb(o, d, inv, b: AABB, max_t: float) -> float | None:
    """Slab test. o = origin, d = unit dir, inv = 1/d per axis."""
    t0, t1 = 0.0, max_t
    for axis, lo, hi in ((0, b.x0, b.x1), (1, b.y0, b.y1), (2, b.z0, b.z1)):
        if d[axis] == 0.0:
            if o[axis] < lo or o[axis] > hi:
                return None
            continue
        ta = (lo - o[axis]) * inv[axis]
        tb = (hi - o[axis]) * inv[axis]
        if ta > tb:
            ta, tb = tb, ta
        t0 = max(t0, ta)
        t1 = min(t1, tb)
        if t0 > t1:
            return None
    return t0


@dataclass
class RayHit:
    distance: float
    point: tuple[float, float, float]
    target: object | None = None     # Combatant or None (world)
    part: str | None = None


class CombatWorld:
    def __init__(self, collision: CollisionWorld, rules):
        self.collision = collision
        self.rules = rules
        self.combatants: list = []
        self.kill_listeners: list = []      # callables(attacker, victim, weapon_name, headshot)
        self.damage_listeners: list = []    # callables(attacker, victim, health_damage)

    # ------------------------------------------------------------------ rays
    def _world_t(self, o, d, inv, max_t: float) -> float:
        # Quick reject: boxes outside the ray's bounding box.
        e = (o[0] + d[0] * max_t, o[1] + d[1] * max_t, o[2] + d[2] * max_t)
        rx0, rx1 = min(o[0], e[0]), max(o[0], e[0])
        ry0, ry1 = min(o[1], e[1]), max(o[1], e[1])
        rz0, rz1 = min(o[2], e[2]), max(o[2], e[2])
        best = max_t
        for b in self.collision.boxes:
            if b.x1 < rx0 or b.x0 > rx1 or b.y1 < ry0 or b.y0 > ry1 or b.z1 < rz0 or b.z0 > rz1:
                continue
            t = ray_aabb(o, d, inv, b, best)
            if t is not None and t < best:
                best = t
        return best

    @staticmethod
    def _inv(d):
        return tuple(1.0 / c if c != 0.0 else 0.0 for c in d)

    def raycast(self, origin, direction, max_dist: float, ignore=None) -> RayHit | None:
        """First thing hit along the ray: map geometry or a combatant hitbox."""
        inv = self._inv(direction)
        best = self._world_t(origin, direction, inv, max_dist)
        hit_target, hit_part = None, None
        for c in self.combatants:
            if c is ignore or not c.alive:
                continue
            for box, part in c.hitboxes():
                t = ray_aabb(origin, direction, inv, box, best)
                if t is not None and t < best:
                    best, hit_target, hit_part = t, c, part
        if hit_target is None and best >= max_dist:
            return None
        p = tuple(origin[i] + direction[i] * best for i in range(3))
        return RayHit(best, p, hit_target, hit_part)

    def line_of_sight(self, a, b) -> bool:
        """True when no map geometry blocks the segment a -> b."""
        dx, dy, dz = b[0] - a[0], b[1] - a[1], b[2] - a[2]
        dist = math.sqrt(dx * dx + dy * dy + dz * dz)
        if dist < 1e-6:
            return True
        d = (dx / dist, dy / dist, dz / dist)
        return self._world_t(a, d, self._inv(d), dist) >= dist - 1e-3

    # ------------------------------------------------------------------ damage
    def can_damage(self, attacker, victim) -> bool:
        if attacker is victim or not victim.alive:
            return False
        return self.rules.friendly_fire or attacker is None or attacker.team != victim.team

    def apply_hit(self, attacker, victim, base: float, distance: float, falloff: float,
                  part: str, weapon_name: str) -> tuple[float, bool]:
        """Apply a hit. Returns (health_damage, killed)."""
        if not self.can_damage(attacker, victim):
            return 0.0, False
        v = victim.vitals
        hp_dmg, armor_lost = compute_damage(base, distance, falloff, part, v.armor, v.helmet, self.rules)
        v.armor = max(0.0, v.armor - armor_lost)
        v.health = max(0.0, v.health - hp_dmg)
        victim.on_damaged(attacker, hp_dmg)
        for fn in self.damage_listeners:
            fn(attacker, victim, hp_dmg)
        killed = v.dead
        if killed:
            victim.on_killed(attacker)
            for fn in self.kill_listeners:
                fn(attacker, victim, weapon_name, part == HEAD)
        return hp_dmg, killed
