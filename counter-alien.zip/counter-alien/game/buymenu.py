"""Buy menu ("Requisition") — original layout.

A narrow ledger panel on the left edge: one row per item with its hotkey,
name, price and status (OWNED / can't afford). Opens with B during the buy
freeze only; closes with B / Esc or automatically when the freeze ends.
Number keys 1-4 (while open) or clicking a row buys.
"""
from __future__ import annotations

from ursina import Button, Entity, Text, Vec2, camera, color, mouse, window

from game.hud import AMBER, DIM, INK, MINT, MONO, TEXT

ORDER = ("rk9", "sd4", "armor", "helmet")


class BuyMenu(Entity):
    def __init__(self, player, economy, rounds, arsenal):
        super().__init__(name="buy_menu")
        self.player, self.economy, self.rm, self.arsenal = player, economy, rounds, arsenal
        self.is_open = False
        x = window.left.x + 0.03
        self.panel = Entity(parent=camera.ui, model="quad", origin=(-0.5, 0.5), position=(x, 0.22, 0.1),
                            scale=(0.56, 0.36), color=INK)
        self.title = Text(parent=camera.ui, text="REQUISITION", font=MONO, position=(x + 0.02, 0.205, -0.01),
                          origin=(-0.5, 0.5), scale=1.1, color=TEXT)
        self.funds = Text(parent=camera.ui, text="", font=MONO, position=(x + 0.54, 0.205, -0.01),
                          origin=(0.5, 0.5), scale=1.1, color=AMBER)
        self.rows = []
        for i, item_id in enumerate(ORDER):
            y = 0.14 - i * 0.055
            b = Button(parent=camera.ui, model="quad", origin=(-0.5, 0.5), position=(x + 0.015, y, -0.01),
                       scale=(0.53, 0.048), color=color.rgba(1, 1, 1, 0.04),
                       highlight_color=color.rgba(1, 1, 1, 0.12), pressed_color=color.rgba(1, 1, 1, 0.2))
            b.on_click = lambda iid=item_id: self.buy(iid)
            label = Text(parent=camera.ui, text="", font=MONO, position=(x + 0.03, y - 0.012, -0.02),
                         origin=(-0.5, 0.5), scale=0.9, color=TEXT)
            status = Text(parent=camera.ui, text="", font=MONO, position=(x + 0.53, y - 0.012, -0.02),
                          origin=(0.5, 0.5), scale=0.9, color=DIM)
            self.rows.append((item_id, b, label, status))
        self.footer = Text(parent=camera.ui, text="", font=MONO, position=(x + 0.02, -0.1, -0.01),
                           origin=(-0.5, 0.5), scale=0.75, color=DIM)
        self.last_msg = ""
        self._set_visible(False)

    def _set_visible(self, v: bool):
        for e in (self.panel, self.title, self.funds, self.footer):
            e.enabled = v
        for _, b, label, status in self.rows:
            b.enabled = label.enabled = status.enabled = v

    def open(self):
        if not self.rm.buy_open or not self.player.alive:
            return
        self.is_open = True
        self.last_msg = ""
        self.arsenal.input_blocked = True
        mouse.locked = False
        self._set_visible(True)

    def close(self, relock: bool = True):
        if not self.is_open:
            return
        self.is_open = False
        self.arsenal.input_blocked = False
        self._set_visible(False)
        if relock:
            mouse.locked = True

    def buy(self, item_id: str):
        if not (self.is_open and self.rm.buy_open):
            return
        item = self.economy.catalog[item_id]
        r = self.economy.purchase(self.player, item_id)
        self.last_msg = {"bought": f"bought {item.name}", "owned": f"{item.name}: already owned",
                         "poor": f"{item.name}: not enough credits"}[r]

    def input(self, key):
        if key == "b":
            self.close() if self.is_open else self.open()
        elif self.is_open and key == "escape":
            self.close(relock=False)
        elif self.is_open and key in ("1", "2", "3", "4"):
            self.buy(ORDER[int(key) - 1])

    def update(self):
        if self.is_open and not self.rm.buy_open:
            self.close()
        if not self.is_open:
            return
        self.funds.text = f"CR {self.player.money:,}"
        for i, (item_id, _b, label, status) in enumerate(self.rows):
            item = self.economy.catalog[item_id]
            label.text = f"{i + 1}  {item.name:<14} {item.price:>5}"
            if self.economy.owns(self.player, item_id):
                status.text, status.color = "OWNED", MINT
            elif self.player.money < item.price:
                status.text, status.color = "--", DIM
            else:
                status.text, status.color = "BUY", AMBER
        self.footer.text = f"{self.last_msg}\n[B] close   buy time {max(0, self.rm.timer):.0f}s"
