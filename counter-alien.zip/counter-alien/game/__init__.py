"""Relay Protocol — an original round-based tactical FPS prototype."""
