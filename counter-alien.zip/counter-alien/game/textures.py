"""Procedurally generated textures (original — no image files are shipped)."""
from __future__ import annotations

import random

from PIL import Image, ImageDraw
from ursina import Texture


def floor_tile(size: int = 128, seed: int = 7) -> Texture:
    """Concrete slab with a thin seam and faint speckle; tiled 1 per 2 m."""
    rng = random.Random(seed)
    img = Image.new("RGB", (size, size), (200, 200, 200))
    px = img.load()
    for y in range(size):
        for x in range(size):
            v = 200 + rng.randint(-10, 10)
            px[x, y] = (v, v, v)
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, size - 1, size - 1], outline=(150, 150, 150), width=2)
    # a small corner notch motif — purely decorative, unique to this project
    d.line([(6, 6), (18, 6)], fill=(170, 170, 170), width=2)
    d.line([(6, 6), (6, 18)], fill=(170, 170, 170), width=2)
    tex = Texture(img)
    tex.filtering = "mipmap"
    return tex


def zone_hatch(size: int = 64) -> Texture:
    """Diagonal hatch used to mark plant zones on the floor."""
    img = Image.new("RGBA", (size, size), (255, 255, 255, 0))
    d = ImageDraw.Draw(img)
    for off in range(-size, size, 16):
        d.line([(off, size), (off + size, 0)], fill=(255, 255, 255, 255), width=5)
    d.rectangle([0, 0, size - 1, size - 1], outline=(255, 255, 255, 255), width=3)
    return Texture(img)
