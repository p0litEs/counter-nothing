"""Round flow, match rules and the flag objective (engine-independent).

RoundManager is a single explicit state machine:

    BUY_FREEZE --(freeze_time)--> LIVE --(win condition)--> ROUND_END
        ^                                                       |
        +------------------(round_end_delay)--------------------+
                                                                |
                                     (a team reached rounds_to_win)
                                                                v
                                                           MATCH_END

Win conditions during LIVE (all timings from config.toml):
    takedown completes                    -> defenders ("takedown")
    post-plant timer expires              -> attackers ("flag_held")
    round timer expires, flag not planted -> defenders ("time")
    [round] elimination_wins = true:
        all attackers down before plant   -> defenders ("elimination")
        all defenders down                -> attackers ("elimination")

Participants (Player, Bot, test dummies) expose:
    team, display_name, alive, is_bot, interact_held, horizontal_speed,
    feet_position() -> (x, y, z), round_reset(spawn_index, survived),
    plus the Economy fields (money, owned, vitals).

TODO(phase 4+): [match] swap_sides_at_halftime is read but not implemented;
sides stay fixed for the whole match in the MVP.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass
from enum import Enum

ATTACKERS, DEFENDERS = "attackers", "defenders"


class Phase(Enum):
    BUY_FREEZE = "buy_freeze"
    LIVE = "live"
    ROUND_END = "round_end"
    MATCH_END = "match_end"


class FlagState(Enum):
    CARRIED = "carried"
    DROPPED = "dropped"
    PLANTED = "planted"


@dataclass
class Interaction:
    kind: str            # "plant" | "takedown"
    progress: float = 0.0


class Flag:
    def __init__(self, home):
        self.home = tuple(home)
        self.reset()

    def reset(self):
        self.state = FlagState.DROPPED
        self.carrier = None
        self.pos = self.home
        self.at_home = True
        self.drop_age = 0.0
        self.site = None          # zone name once planted

    def give(self, carrier):
        self.state, self.carrier, self.at_home, self.drop_age = FlagState.CARRIED, carrier, False, 0.0
        self.pos = carrier.feet_position()

    def drop(self, pos):
        self.state, self.carrier, self.pos, self.drop_age, self.at_home = FlagState.DROPPED, None, tuple(pos), 0.0, False

    def plant(self, pos, site: str):
        self.state, self.carrier, self.pos, self.site = FlagState.PLANTED, None, tuple(pos), site


class RoundManager:
    def __init__(self, cfg, plant_zones, flag_home, participants, economy, rng=None):
        self.cfg = cfg
        self.zones = list(plant_zones)
        self.participants = list(participants)
        self.economy = economy
        self.rng = rng or random.Random()
        self.flag = Flag(flag_home)
        self.listeners = []                 # fn(event: str, **data)
        self.interactions: dict = {}        # actor -> Interaction
        self._damaged: set = set()
        self.phase = Phase.MATCH_END
        self.timer = 0.0
        self.round_number = 0
        self.score = {ATTACKERS: 0, DEFENDERS: 0}
        self.round_winner = None
        self.round_reason = ""
        self.match_winner = None
        self.history: list[tuple[str, str]] = []

    # ------------------------------------------------------------ events
    def emit(self, event: str, **data):
        for fn in self.listeners:
            fn(event, **data)

    # ------------------------------------------------------------ match / rounds
    def start_match(self):
        self.score = {ATTACKERS: 0, DEFENDERS: 0}
        self.round_number = 0
        self.match_winner = None
        self.history = []
        self.economy.start_match(self.participants)
        for p in self.participants:
            p.alive = False                  # nobody "survived" into round 1: fresh loadouts
        self.emit("match_start")
        self.start_round()

    def start_round(self):
        self.round_number += 1
        self.flag.reset()
        self.interactions.clear()
        self._damaged.clear()
        self.round_winner, self.round_reason = None, ""
        counters = {ATTACKERS: 0, DEFENDERS: 0}
        for p in self.participants:
            survived = p.alive
            p.round_reset(counters[p.team], survived)
            counters[p.team] += 1
        for p in self.participants:
            if p.is_bot:
                self.economy.auto_buy(p)
        self._assign_carrier()
        self.phase = Phase.BUY_FREEZE
        self.timer = self.cfg.round.freeze_time
        self.emit("round_start", round=self.round_number)

    def _assign_carrier(self):
        attackers = [p for p in self.participants if p.team == ATTACKERS and p.alive]
        bots = [p for p in attackers if p.is_bot]
        pool = bots or attackers
        if pool:
            self.flag.give(self.rng.choice(pool))

    def end_round(self, winner: str, reason: str):
        if self.phase != Phase.LIVE:
            return
        self.round_winner, self.round_reason = winner, reason
        self.score[winner] += 1
        self.history.append((winner, reason))
        self.economy.on_round_end(winner, self.participants)
        self.interactions.clear()
        if self.score[winner] >= self.cfg.match.rounds_to_win:
            self.match_winner = winner
        self.phase = Phase.ROUND_END
        self.timer = self.cfg.round.round_end_delay
        self.emit("round_end", winner=winner, reason=reason)

    def skip_round_end(self):
        """F5 during ROUND_END: go straight to the next round (or match end)."""
        if self.phase == Phase.ROUND_END:
            self.timer = 0.0
            self.tick(0.0)

    # ------------------------------------------------------------ queries
    @property
    def movement_locked(self) -> bool:
        return self.phase in (Phase.BUY_FREEZE, Phase.MATCH_END)

    @property
    def buy_open(self) -> bool:
        return self.phase == Phase.BUY_FREEZE

    def speed_multiplier(self, actor) -> float:
        if self.flag.state == FlagState.CARRIED and self.flag.carrier is actor:
            return self.cfg.flag.carrier_speed_multiplier
        return 1.0

    def zone_for(self, actor):
        x, y, z = actor.feet_position()
        for zone in self.zones:
            if zone.contains(x, z) and abs(y - zone.floor_y) < 1.0:
                return zone
        return None

    def distance_to_flag(self, actor) -> float:
        x, y, z = actor.feet_position()
        fx, fy, fz = self.flag.pos
        return math.sqrt((x - fx) ** 2 + (y - fy) ** 2 + (z - fz) ** 2)

    def interaction_kind(self, actor) -> str | None:
        """What holding E would do for this actor right now (None = nothing)."""
        if self.phase != Phase.LIVE or not actor.alive:
            return None
        f = self.flag
        if (actor.team == ATTACKERS and f.state == FlagState.CARRIED and f.carrier is actor
                and self.zone_for(actor) is not None):
            return "plant"
        if (actor.team == DEFENDERS and f.state == FlagState.PLANTED
                and self.distance_to_flag(actor) <= self.cfg.flag.interact_radius):
            return "takedown"
        return None

    def progress_for(self, actor) -> tuple[str, float] | None:
        it = self.interactions.get(actor)
        if not it:
            return None
        need = self.cfg.flag.plant_time if it.kind == "plant" else self.cfg.flag.takedown_time
        return it.kind, min(1.0, it.progress / need)

    def post_plant_left(self) -> float | None:
        return self.timer if (self.phase == Phase.LIVE and self.flag.state == FlagState.PLANTED) else None

    # ------------------------------------------------------------ hooks
    def on_kill(self, attacker, victim):
        if self.phase in (Phase.LIVE, Phase.ROUND_END):
            self.economy.on_kill(attacker, victim)
        if self.flag.state == FlagState.CARRIED and self.flag.carrier is victim:
            self.flag.drop(victim.feet_position())
            self.emit("flag_drop", by=victim)
        self.interactions.pop(victim, None)

    def on_damaged(self, victim):
        self._damaged.add(victim)

    # ------------------------------------------------------------ tick
    def tick(self, dt: float):
        if self.phase == Phase.MATCH_END:
            return
        self.timer -= dt
        if self.phase == Phase.BUY_FREEZE:
            self._tick_flag(0.0)
            if self.timer <= 0:
                self.phase = Phase.LIVE
                self.timer = self.cfg.round.round_time
                self.emit("live")
            return
        if self.phase == Phase.ROUND_END:
            if self.timer <= 0:
                if self.match_winner:
                    self.phase = Phase.MATCH_END
                    self.emit("match_end", winner=self.match_winner)
                else:
                    self.start_round()
            return

        # ---- LIVE
        self._tick_flag(dt)
        self._tick_interactions(dt)
        if self.phase != Phase.LIVE:
            return
        planted = self.flag.state == FlagState.PLANTED
        if self.timer <= 0:
            self.end_round(ATTACKERS, "flag_held") if planted else self.end_round(DEFENDERS, "time")
            return
        if self.cfg.round.elimination_wins:
            atk = any(p.alive for p in self.participants if p.team == ATTACKERS)
            dfn = any(p.alive for p in self.participants if p.team == DEFENDERS)
            if not dfn:
                self.end_round(ATTACKERS, "elimination")
            elif not atk and not planted:
                self.end_round(DEFENDERS, "elimination")

    def _tick_flag(self, dt):
        f, fc = self.flag, self.cfg.flag
        if f.state == FlagState.CARRIED:
            if not f.carrier.alive:
                f.drop(f.carrier.feet_position())
                self.emit("flag_drop", by=None)
            else:
                f.pos = f.carrier.feet_position()
            return
        if f.state != FlagState.DROPPED:
            return
        # pickup by any living attacker inside the radius
        fx, fy, fz = f.pos
        for p in self.participants:
            if p.team != ATTACKERS or not p.alive:
                continue
            x, y, z = p.feet_position()
            if math.hypot(x - fx, z - fz) <= fc.pickup_radius and abs(y - fy) < 1.5:
                f.give(p)
                self.emit("flag_pickup", by=p)
                return
        if not f.at_home:
            f.drop_age += dt
            if f.drop_age >= fc.flag_return_time:
                f.pos, f.at_home, f.drop_age = f.home, True, 0.0
                self.emit("flag_return")

    def _tick_interactions(self, dt):
        fc = self.cfg.flag
        damaged, self._damaged = self._damaged, set()
        for actor in self.participants:
            kind = self.interaction_kind(actor) if actor.interact_held else None
            if kind is None:
                self.interactions.pop(actor, None)
                continue
            it = self.interactions.get(actor)
            if it is None or it.kind != kind:
                it = self.interactions[actor] = Interaction(kind)
            if actor.horizontal_speed > fc.interrupt_speed or actor in damaged:
                it.progress = 0.0                         # interrupted: start over
                continue
            it.progress += dt
            need = fc.plant_time if kind == "plant" else fc.takedown_time
            if it.progress >= need:
                if kind == "plant":
                    zone = self.zone_for(actor)
                    self.flag.plant(actor.feet_position(), zone.name)
                    self.interactions.clear()
                    self.timer = fc.post_plant_time
                    self.emit("plant", by=actor, site=zone.name)
                else:
                    self.emit("takedown", by=actor)
                    self.end_round(DEFENDERS, "takedown")
                return
