"""Minimal original HUD.

Layout (designed for this project):
  top-left      location callout + credits, kill feed below
  top-right     score card (team tallies) with the round clock and phase label
  centre        X-shaped crosshair whose gap widens with weapon spread,
                orthogonal-tick hitmarker, ammo readout tucked to the lower-right
                of the crosshair, flag-progress bar below (hidden until used)
  bottom-centre health / armor as two slim labelled bars (helmet tag on armor)
  bottom-left   speed readout (shows the Field Knife boost live)
  bottom-right  weapon slot list, active slot highlighted
Palette: ink-navy panels, off-white text, mint health, periwinkle armor,
amber credits; team colours teal (attackers) and coral (defenders).
"""
from __future__ import annotations

from ursina import Entity, Text, Vec2, camera, color, time, window

MONO = "VeraMono.ttf"   # Bitstream Vera (free licence), bundled with Ursina

INK = color.rgba(0.05, 0.07, 0.11, 0.72)
TEXT = color.rgba(0.93, 0.94, 0.90, 1)
DIM = color.rgba(0.70, 0.73, 0.78, 1)
MINT = color.rgba(0.36, 0.90, 0.62, 1)
PERI = color.rgba(0.56, 0.63, 1.00, 1)
AMBER = color.rgba(1.00, 0.76, 0.30, 1)
ATTACK_COL = color.rgba(0.20, 0.80, 0.80, 1)
DEFEND_COL = color.rgba(1.00, 0.46, 0.40, 1)
FLAG = color.rgba(0.98, 0.92, 0.40, 1)
HIT = color.rgba(1.0, 1.0, 1.0, 1)
HIT_HEAD = color.rgba(1.0, 0.80, 0.25, 1)
HIT_KILL = color.rgba(1.0, 0.35, 0.30, 1)
HURT = color.rgba(0.85, 0.12, 0.10, 0.0)

CROSSHAIR_COLORS = {
    "Green": color.rgb(90, 230, 125),
    "Cyan": color.rgb(60, 220, 235),
    "Magenta": color.rgb(235, 90, 220),
    "White": color.rgb(240, 240, 240),
    "Yellow": color.rgb(240, 220, 70),
}


def _quad(pos, scale, col, z=0.0, origin=(-0.5, 0)):
    return Entity(parent=camera.ui, model="quad", origin=origin,
                  position=(pos[0], pos[1], z), scale=scale, color=col)


def _text(txt, pos, scale=1.0, col=TEXT, origin=(-0.5, 0.5), font=MONO, z=-0.02):
    return Text(parent=camera.ui, text=txt, position=(pos[0], pos[1], z), scale=scale,
                origin=origin, color=col, font=font)


class Bar:
    """A slim labelled bar: LABEL ............ 100 above a fill strip."""

    def __init__(self, pos, width, label, fill_col):
        x, y = pos
        self.width = width
        self.bg = _quad((x, y), (width, 0.014), INK, z=0)
        self.fill = _quad((x, y), (width, 0.014), fill_col, z=-0.01)
        self.label = _text(label, (x, y + 0.012), 0.75, DIM, origin=(-0.5, -0.5))
        self.value = _text("0", (x + width, y + 0.012), 0.9, fill_col, origin=(0.5, -0.5))

    def set(self, value: float, maximum: float, label: str | None = None):
        frac = max(0.0, min(1.0, value / maximum if maximum else 0))
        self.fill.scale_x = max(self.width * frac, 0.0001)
        self.fill.visible = frac > 0
        self.value.text = f"{int(round(value))}"
        if label is not None:
            self.label.text = label


class HUD:
    def __init__(self, cfg):
        self.cfg = cfg
        tl, tr = window.top_left, window.top_right
        bl, br, bottom = window.bottom_left, window.bottom_right, window.bottom

        # ---- crosshair: four orthogonal bars plus an optional centre dot
        self.cross = []
        self.cross_dirs = ((-1, 0, 0), (1, 0, 0), (0, -1, 90), (0, 1, 90))
        for _ in range(4):
            self.cross.append(Entity(parent=camera.ui, model="quad", color=TEXT,
                                     position=(0, 0, -0.03), scale=(0.01, 0.01)))
        self.cross_dot = Entity(parent=camera.ui, model="quad", color=TEXT,
                                position=(0, 0, -0.03), scale=(0.004, 0.004))
        self.cross_dot.visible = False
        self.cross_settings = {
            "crosshair_color": cfg.view.crosshair_color,
            "size": cfg.view.crosshair_size,
            "thickness": cfg.view.crosshair_thickness,
            "gap": cfg.view.crosshair_gap,
            "style": cfg.view.crosshair_style,
            "dynamic": cfg.view.crosshair_dynamic,
        }
        self.apply_crosshair_settings()
        # ---- hitmarker: four orthogonal ticks (distinct from the crosshair)
        self.hit_ticks = []
        for dx, dy, rot in ((1, 0, 0), (-1, 0, 0), (0, 1, 90), (0, -1, 90)):
            self.hit_ticks.append(Entity(parent=camera.ui, model="quad", color=HIT,
                                         position=(dx * 0.024, dy * 0.024, -0.031),
                                         scale=(0.014, 0.003), rotation_z=rot, enabled=False))
        self.hit_t = 0.0

        # ---- damage flash (full-screen tint)
        self.hurt = Entity(parent=camera.ui, model="quad", scale=(window.aspect_ratio * 1.05, 1.05),
                           color=HURT, z=0.5)
        self.hurt_t = 0.0

        # ---- top-left: location + credits + kill feed
        self.location = _text("", tl + Vec2(0.03, -0.03), 1.0, TEXT)
        self.credits = _text("", tl + Vec2(0.03, -0.065), 1.0, AMBER)
        self.feed_lines: list[list] = []     # [text, age]
        self.feed = _text("", tl + Vec2(0.03, -0.11), 0.75, DIM)

        # ---- top-right: score card (both team names + scores)
        card_w = 0.34
        cx = tr.x - 0.03 - card_w
        _quad((cx, tr.y - 0.075), (card_w, 0.11), INK, z=0)
        self.atk_score = _text("0", (cx + 0.02, tr.y - 0.035), 1.6, ATTACK_COL)
        self.def_score = _text("0", (cx + card_w - 0.02, tr.y - 0.035), 1.6, DEFEND_COL, origin=(0.5, 0.5))
        self.atk_label = _text(cfg.teams.attackers_name.upper(), (cx + 0.02, tr.y - 0.095), 0.7, DIM)
        self.def_label = _text(cfg.teams.defenders_name.upper(), (cx + card_w - 0.02, tr.y - 0.095), 0.7, DIM,
                               origin=(0.5, 0.5))
        _text("FIRST TO", (cx + card_w / 2, tr.y - 0.03), 0.6, DIM, origin=(0, 0.5))
        self.goal = _text(str(cfg.match.rounds_to_win), (cx + card_w / 2, tr.y - 0.052), 1.1, TEXT, origin=(0, 0.5))

        # ---- top-centre: round clock, phase, flag status
        self.clock_bg = _quad((0, tr.y - 0.05), (0.2, 0.075), INK, z=0, origin=(0, 0))
        self.clock = _text("0:00", (0, tr.y - 0.018), 1.7, TEXT, origin=(0, 0.5))
        self.phase = _text("", (0, tr.y - 0.1), 0.75, DIM, origin=(0, 0.5))
        self.flag_status = _text("", (0, tr.y - 0.128), 0.75, FLAG, origin=(0, 0.5))

        # ---- round / match banner (centre band)
        self.banner_bg = _quad((0, 0.2), (window.aspect_ratio * 1.05, 0.11), INK, z=-0.04, origin=(0, 0))
        self.banner = _text("", (0, 0.2), 2.0, TEXT, origin=(0, 0), z=-0.05)
        self.banner_sub = _text("", (0, 0.155), 0.85, DIM, origin=(0, 0), z=-0.05)
        self.set_banner(None)

        # ---- centre: ammo + flag progress + death notice
        self.ammo = _text("", (0.035, -0.025), 0.9, TEXT)
        self.flag_bg = _quad((-0.15, bottom.y + 0.15), (0.3, 0.012), INK, z=0)
        self.flag_fill = _quad((-0.15, bottom.y + 0.15), (0.3, 0.012), FLAG, z=-0.01)
        self.flag_label = _text("", (0, bottom.y + 0.185), 0.8, FLAG, origin=(0, 0.5))
        self.set_flag_progress(None)
        self.carrier = _text("", (0, bottom.y + 0.115), 0.9, FLAG, origin=(0, 0.5))
        self.death = _text("", (0, 0.08), 1.4, TEXT, origin=(0, 0))

        # ---- bottom-centre: health + armor
        self.health = Bar((-0.25, bottom.y + 0.05), 0.22, "HEALTH", MINT)
        self.armor = Bar((0.03, bottom.y + 0.05), 0.22, "ARMOR", PERI)

        # ---- bottom-left: speed  |  bottom-right: weapon slots
        self.speed = _text("", bl + Vec2(0.03, 0.075), 0.85, TEXT, origin=(-0.5, 0))
        self.slots = _text("", br + Vec2(-0.03, 0.05), 0.8, DIM, origin=(0.5, -0.5))
        self.slot_active = _text("", br + Vec2(-0.03, 0.05), 0.8, TEXT, origin=(0.5, -0.5))

        # ---- prompts / overlays
        self.prompt = _text("", (0, -0.16), 0.9, TEXT, origin=(0, 0.5))
        self.hint = _text("F1  controls", bl + Vec2(0.03, 0.04), 0.7, DIM, origin=(-0.5, 0))
        self.help = _text(
            "MOVE      W A S D          FIRE      Left mouse\n"
            "JUMP      Space            RELOAD    R\n"
            "CROUCH    Ctrl / C         WEAPONS   1 2 3 / wheel\n"
            "WALK      Shift\n"
            "MOUSE     Esc releases, click to recapture\n"
            "PLANT / TAKE DOWN  hold E  BUY MENU  B (buy phase)\n"
            "F5   respawn (buy phase) / next round / new match\n"
            "SETTINGS  F4               DEBUG        F3\n"
            "QUIT      F10",
            (0, 0.24), 0.85, TEXT, origin=(0, 0.5))
        self.help_bg = _quad((0, 0.14), (1.1, 0.29), INK, z=-0.015, origin=(0, 0))
        self.toggle_help(False)
        self.debug = _text("", br + Vec2(-0.03, 0.2), 0.7, DIM, origin=(0.5, -0.5))
        self.debug.visible = False
        self.fps = _text("", tr + Vec2(-0.03, -0.155), 0.65, DIM, origin=(0.5, 0.5))

    # ------------------------------------------------------------------ setters
    def set_location(self, name: str):
        self.location.text = name.upper() if name else ""

    def set_credits(self, amount: int):
        self.credits.text = f"CR {amount:,}"

    def set_score(self, attackers: int, defenders: int):
        self.atk_score.text = str(attackers)
        self.def_score.text = str(defenders)

    def set_player_team(self, team: str):
        """Brackets mark the player's side on the score card: [VAN]."""
        t = self.cfg.teams
        mine = team == "attackers"
        an, dn = t.attackers_name.upper(), t.defenders_name.upper()
        self.atk_label.text = f"[{an}]" if mine else an
        self.def_label.text = dn if mine else f"[{dn}]"
        self.atk_label.color = TEXT if mine else DIM
        self.def_label.color = DIM if mine else TEXT

    def set_clock(self, seconds: float, phase_label: str, urgent: bool = False):
        s = max(0, int(seconds + 0.999))
        self.clock.text = f"{s // 60}:{s % 60:02d}"
        self.clock.color = FLAG if urgent else TEXT
        self.phase.text = phase_label

    def set_flag_status(self, text: str):
        self.flag_status.text = text

    def set_carrier(self, carrying: bool):
        self.carrier.text = "YOU HAVE THE FLAG" if carrying else ""

    def set_banner(self, text: str | None, col=None, sub: str = ""):
        show = bool(text)
        self.banner_bg.visible = show
        self.banner.text = text or ""
        self.banner.color = col or TEXT
        self.banner_sub.text = sub if show else ""

    def team_color(self, team: str):
        return ATTACK_COL if team == "attackers" else DEFEND_COL

    def set_vitals(self, health: float, armor: float, helmet: bool = False):
        self.health.set(health, self.cfg.player.max_health)
        self.armor.set(armor, self.cfg.player.max_armor, "ARMOR + HELMET" if helmet else "ARMOR")

    def set_weapon(self, w, slots: dict):
        """w: active WeaponState; slots: {slot: WeaponState}."""
        d = w.d
        if d.is_melee:
            self.ammo.text = d.name
        elif w.reloading:
            self.ammo.text = f"--/{w.reserve if not w.infinite_reserve else 'inf'}\n{d.name}  RELOADING"
        else:
            self.ammo.text = f"{w.mag}/{w.reserve}\n{d.name}"
        rows = [f"{s}  {slots[s].d.name}" for s in sorted(slots)]
        self.slots.text = "\n".join(r if s != w.d.slot else " " * len(r) for s, r in zip(sorted(slots), rows))
        self.slot_active.text = "\n".join(r if s == w.d.slot else " " * len(r)
                                          for s, r in zip(sorted(slots), rows))

    def set_speed(self, speed: float, max_speed: float, multiplier: float):
        # the multiplier is relative to base run speed (movement.run_speed), not to another weapon
        tag = f"  x{multiplier:.2f} of base" if abs(multiplier - 1.0) > 1e-3 else ""
        self.speed.text = f"SPEED {speed:4.1f} / {max_speed:3.1f} m/s{tag}"
        self.speed.color = AMBER if multiplier > 1.0 else TEXT

    def set_spread(self, spread_deg: float):
        dynamic = spread_deg * self.cfg.view.crosshair_gap_per_degree if self.cross_settings["dynamic"] else 0.0
        aspect = window.aspect_ratio
        gap = float(self.cross_settings["gap"]) + dynamic
        length = float(self.cross_settings["size"])
        thickness = float(self.cross_settings["thickness"])
        horizontal_scale = (length * aspect, thickness)
        vertical_scale = (thickness * aspect, length)
        col = CROSSHAIR_COLORS.get(self.cross_settings["crosshair_color"], TEXT)
        for e, (rx, ry, rot) in zip(self.cross, self.cross_dirs):
            if rx:
                e.position = (rx * (gap + length / 2) * aspect, 0, -0.03)
                e.scale = horizontal_scale
            else:
                e.position = (0, ry * (gap + length / 2), -0.03)
                e.scale = vertical_scale
            e.rotation_z = rot
            e.color = col
        self.cross_dot.scale = (thickness * aspect * 1.5, thickness * 1.5)
        self.cross_dot.color = col

    def apply_crosshair_settings(self, values=None):
        if values:
            self.cross_settings.update(values)
        style = self.cross_settings["style"]
        show_cross = style in ("Cross", "Cross+Dot")
        show_dot = style in ("Dot", "Cross+Dot")
        for e in self.cross:
            e.visible = show_cross
        self.cross_dot.visible = show_dot
        self.set_spread(0)

    def set_flag_progress(self, fraction: float | None, label: str = ""):
        show = fraction is not None
        for e in (self.flag_bg, self.flag_fill, self.flag_label):
            e.visible = show
        if show:
            self.flag_fill.scale_x = max(0.3 * max(0.0, min(1.0, fraction)), 0.0001)
            self.flag_label.text = label

    def set_prompt(self, text: str):
        self.prompt.text = text

    def set_death(self, seconds_left: float | None, killer: str = ""):
        if seconds_left is None:
            self.death.text = ""
        else:
            by = f" by {killer}" if killer else ""
            self.death.text = (f"DOWN{by}\nback next round" if seconds_left == float("inf")
                               else f"DOWN{by}\nredeploying in {max(0, seconds_left):.0f}")
        for e in self.cross:
            e.visible = seconds_left is None
        self.cross_dot.visible = seconds_left is None and self.cross_settings["style"] in ("Dot", "Cross+Dot")

    def toggle_help(self, show: bool | None = None):
        show = (not self.help.visible) if show is None else show
        self.help.visible = show
        self.help_bg.visible = show

    # ------------------------------------------------------------------ events
    def hitmarker(self, headshot: bool, killed: bool):
        col = HIT_KILL if killed else (HIT_HEAD if headshot else HIT)
        for e in self.hit_ticks:
            e.color = col
            e.enabled = True
        self.hit_t = self.cfg.view.hitmarker_time * (1.6 if killed else 1.0)

    def damage_flash(self, amount: float):
        self.hurt_t = self.cfg.view.damage_flash_time * min(1.0, 0.3 + amount / 40.0)

    def add_kill(self, line: str):
        self.feed_lines.append([line, 0.0])
        self.feed_lines = self.feed_lines[-5:]

    def tick(self):
        dt = time.dt
        if self.hit_t > 0:
            self.hit_t -= dt
            if self.hit_t <= 0:
                for e in self.hit_ticks:
                    e.enabled = False
        if self.hurt_t > 0:
            self.hurt_t = max(0.0, self.hurt_t - dt)
        self.hurt.color = color.rgba(HURT[0], HURT[1], HURT[2], 0.45 * self.hurt_t / max(self.cfg.view.damage_flash_time, 1e-3))
        for line in self.feed_lines:
            line[1] += dt
        self.feed_lines = [l for l in self.feed_lines if l[1] < 6.0]
        self.feed.text = "\n".join(l[0] for l in self.feed_lines)
