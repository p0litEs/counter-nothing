"""Original maps for Relay Protocol."""
