"""RELAY STATION — original map designed for this project.

Premise: a hill-top signal relay facility at dusk. Two objective sites:
  * Site Alpha  — "Antenna Yard": an open-air raised pad with a dish mast,
                  reached on foot from the yard or by dropping off the Gantry.
  * Site Bravo  — "Generator Hall": an enclosed hall with generator blocks and
                  a high catwalk; three narrow entrances.

The layout is drawn from scratch on a 120 m x 96 m grid (x = east, z = north).
It is NOT derived from any existing game's map.

    z=+48  +---------------------------------------------------------------+
           | ####### |  Back Hall  |  North Post   |   Ridge Walk         |
           | ####### |             |   (spawn)     |----------  ##########|
    z=+30  |---------+--door--+    |  North Court  | Control  | Alpha     |
           | Generator Hall   |Pump|               |  Block   | Yard  [A] |
           |   [B]   catwalk  |Cor.|-----gate------+---Gantry=====> pad   |
           |                 door  |               | Overlook |           |
    z=+4   |-----door---------+----|  Switchyard   |          gate        |
           |                       |   (tower)     |                      |
           |   Loading Dock     breach             |  Cable  | Transformer|
           |   (dock platform)     |               |  Run    |  Block     |
    z=-35  |                       +-----gate------+         |  ########  |
           |              South Muster (spawn)               |  ########  |
    z=-48  +---------------------------------------------------------------+
         x=-60                                                          x=+60

This module is pure data (no engine imports) so it can be validated headless.
"""
from __future__ import annotations

from dataclasses import dataclass

from game.physics import AABB

WALL_H = 6.0       # interior wall height
EDGE_H = 10.0      # perimeter wall height
FILL_H = 8.0       # solid out-of-bounds blocks


@dataclass(frozen=True, slots=True)
class Solid:
    box: AABB
    material: str


@dataclass(frozen=True, slots=True)
class Zone:
    """A named 2D region (callouts, plant zones, spawns)."""
    name: str
    x0: float
    z0: float
    x1: float
    z1: float
    kind: str = "area"          # "area" | "plant"
    floor_y: float = 0.0        # where to draw the floor marking

    def contains(self, x: float, z: float) -> bool:
        return self.x0 <= x <= self.x1 and self.z0 <= z <= self.z1


SOLIDS: list[Solid] = []


def box(x0, x1, z0, z1, y0=0.0, y1=WALL_H, mat="wall"):
    """Add a solid box. Arguments are min/max per axis (metres)."""
    SOLIDS.append(Solid(AABB(min(x0, x1), y0, min(z0, z1), max(x0, x1), y1, max(z0, z1)), mat))


def stairs(steps, *, axis, start, step_depth, span0, span1, rise, base=0.0, mat="stair"):
    """Straight staircase. axis='x' or 'z' is the climbing direction; a negative
    step_depth climbs toward negative coordinates."""
    for i in range(steps):
        a0 = start + i * step_depth
        a1 = a0 + step_depth
        top = base + rise * (i + 1)
        if axis == "x":
            box(a0, a1, span0, span1, base, top, mat)
        else:
            box(span0, span1, a0, a1, base, top, mat)


# --------------------------------------------------------------------------- #
#  Ground + perimeter
# --------------------------------------------------------------------------- #
box(-61, 61, -49, 49, -1.0, 0.0, "floor")
box(-61, -60, -49, 49, 0, EDGE_H, "edge")
box(60, 61, -49, 49, 0, EDGE_H, "edge")
box(-61, 61, -49, -48, 0, EDGE_H, "edge")
box(-61, 61, 48, 49, 0, EDGE_H, "edge")

# Solid out-of-bounds masses (shape the playable space)
box(34, 60, -48, 0, 0, FILL_H, "fill")        # Transformer Block
box(-60, -40, 30, 48, 0, FILL_H, "fill")      # NW rock shelf
box(24, 60, 40, 48, 0, FILL_H, "fill")        # NE rock shelf
box(12, 24, 21, 33, 0, FILL_H, "fill")        # Control Block

# --------------------------------------------------------------------------- #
#  South Muster (attacker spawn, south) and its north wall
# --------------------------------------------------------------------------- #
box(-22, -5, -36, -35)                        # muster wall, west of gate
box(5, 22, -36, -35)                          # muster wall, east of gate
box(-8, -5, -44, -42, 0, 1.2, "crate")
box(6, 9, -41, -39, 0, 1.2, "crate")

# --------------------------------------------------------------------------- #
#  Switchyard (central plaza) — relay tower blocks the long sightline
# --------------------------------------------------------------------------- #
box(-5, 5, -5, 5, 0, 12.0, "tower")
# west wall: gaps at z[-14,-8] (Breach -> Loading Dock) and z[8,14] (-> Pump Corridor)
box(-23, -22, -35, -14)
box(-23, -22, -8, 8)
box(-23, -22, 14, 30)
# north wall with the Spine Gate at x[-4,4]
box(-22, -4, 20, 21)
box(4, 24, 20, 21)
# east wall: Switch Gate gap at z[2,8]; low section under the Gantry
box(22, 24, -35, 2)
box(22, 24, 8, 13)
box(22, 24, 13, 19, 0, 2.6)                   # under-gantry section (gantry deck sits on top)
box(22, 24, 19, 21)
# cover
box(-14, -11, -22, -19, 0, 1.4, "crate")
box(8, 11, -14, -11, 0, 2.2, "crate")
box(-16, -13, 8, 11, 0, 1.2, "crate")
box(-3, 3, 12, 13, 0, 1.2, "lowwall")
box(10, 13, -28, -25, 0, 1.4, "crate")
# Overlook: raised platform in the NE corner of the Switchyard, stairs on its south face
box(14, 22, 11, 20, 0, 3.0, "deck")
stairs(5, axis="z", start=6, step_depth=1.0, span0=16, span1=20, rise=0.5)   # 0.5 .. 2.5 then deck

# --------------------------------------------------------------------------- #
#  Gantry — elevated bridge from the Overlook over the east wall to Alpha pad
# --------------------------------------------------------------------------- #
box(22, 38, 14, 18, 2.6, 3.0, "deck")
box(22, 38, 13.85, 14.0, 3.0, 3.9, "rail")
box(22, 38, 18.0, 18.15, 3.0, 3.9, "rail")

# --------------------------------------------------------------------------- #
#  Cable Run (south-east lane) — South Muster -> Antenna Yard
# --------------------------------------------------------------------------- #
box(28, 31, -26, -23, 0, 1.4, "crate")
box(24, 27, -12, -9, 0, 1.6, "crate")
box(29, 34, -4, -3, 0, 3.0, "lowwall")

# --------------------------------------------------------------------------- #
#  SITE ALPHA — Antenna Yard (north-east)
# --------------------------------------------------------------------------- #
box(24, 44, 32, 33)                           # yard north wall, Ridge Door at x[44,50]
box(50, 60, 32, 33)
box(38, 60, 12, 28, 0, 1.5, "pad")            # the raised pad
stairs(2, axis="x", start=36, step_depth=1.0, span0=19, span1=25, rise=0.5)  # west steps
stairs(2, axis="z", start=10, step_depth=1.0, span0=46, span1=52, rise=0.5)  # south steps
box(50, 54, 22, 26, 1.5, 4.5, "mast")         # dish mast base (cover on the pad)
box(42, 44, 14, 16, 1.5, 2.7, "crate")
box(44, 46, 24, 27, 1.5, 2.5, "crate")
box(28, 31, 4, 7, 0, 1.4, "crate")            # yard cover
box(30, 32, 22, 30, 0, 1.3, "lowwall")

# --------------------------------------------------------------------------- #
#  SITE BRAVO — Generator Hall (north-west)
# --------------------------------------------------------------------------- #
box(-60, -48, 4, 5)                           # south wall, Dock Door at x[-48,-42]
box(-42, -23, 4, 5)                           # (also closes the Pump Corridor's south end)
box(-31, -30, 4, 14)                          # east wall, Hall Door at z[14,19]
box(-31, -30, 19, 30)
box(-60, -40, 29, 30)                         # north wall, Back Door at x[-40,-35]
box(-35, -30, 29, 30)
box(-60, -46, 24, 29, 0, 3.0, "deck")         # catwalk ledge
stairs(5, axis="x", start=-41, step_depth=-1.0, span0=24, span1=29, rise=0.5)  # climbs west
box(-56, -50, 12, 18, 0, 3.2, "generator")
box(-44, -40, 16, 20, 0, 2.2, "generator")
box(-38, -35, 8, 11, 0, 1.2, "crate")

# --------------------------------------------------------------------------- #
#  Loading Dock (south-west)
# --------------------------------------------------------------------------- #
box(-60, -46, -22, -8, 0, 1.2, "dock")
box(-45, -44, -18, -12, 0, 0.4, "stair")
box(-46, -45, -18, -12, 0, 0.8, "stair")
box(-40, -34, -30, -26, 0, 2.6, "container")
box(-34, -28, -6, -2, 0, 2.6, "container")
box(-52, -49, -4, -1, 0, 1.4, "crate")

# --------------------------------------------------------------------------- #
#  North Post (defender spawn, north), North Court, Ridge Walk, Back Hall
# --------------------------------------------------------------------------- #
box(-6, -3, 40, 42, 0, 1.2, "crate")
box(5, 8, 42, 44, 0, 1.2, "crate")
box(-10, -7, 26, 29, 0, 1.4, "crate")
box(30, 33, 35, 37, 0, 1.4, "crate")
box(-30, -27, 36, 39, 0, 1.6, "crate")

# --------------------------------------------------------------------------- #
#  Zones: callouts (HUD location readout), plant zones and spawns
# --------------------------------------------------------------------------- #
PLANT_ZONES = [
    Zone("Site Alpha", 40, 14, 56, 26, "plant", floor_y=1.5),
    Zone("Site Bravo", -50, 7, -36, 22, "plant", floor_y=0.0),
]

# Ordered most-specific first; first match wins.
CALLOUTS = PLANT_ZONES + [
    Zone("Gantry", 22, 14, 38, 18),
    Zone("Overlook", 14, 6, 22, 20),
    Zone("Generator Hall", -60, 5, -31, 29),
    Zone("Antenna Yard", 24, 0, 60, 32),
    Zone("Pump Corridor", -30, 5, -23, 30),
    Zone("Back Hall", -40, 30, -12, 48),
    Zone("North Post", -12, 37, 12, 48),
    Zone("Ridge Walk", 12, 33, 60, 40),
    Zone("North Court", -22, 21, 12, 37),
    Zone("Cable Run", 24, -48, 34, 0),
    Zone("Switchyard", -22, -35, 22, 20),
    Zone("South Muster", -23, -48, 24, -35),
    Zone("Loading Dock", -60, -48, -23, 4),
]

SPAWNS = {
    "attackers": [(-12.0, -45.0), (-3.0, -46.0), (3.0, -46.0), (12.0, -45.0), (0.0, -38.5)],
    "defenders": [(-9.0, 46.0), (-1.0, 46.0), (2.0, 39.0), (10.0, 46.0), (-9.0, 40.0)],
}
SPAWN_YAW = {"attackers": 0.0, "defenders": 180.0}   # degrees; 0 = facing north (+z)

BOUNDS = (-60.0, -48.0, 60.0, 48.0)

# Named navigation goals (x, y, z) used by bots. Phase 3 adds objective points.
NAV_POINTS = {
    "attacker_spawn": (0.0, 0.0, -42.0),
    "defender_spawn": (0.0, 0.0, 43.0),
    "switchyard":     (-12.0, 0.0, -12.0),
    "north_court":    (-6.0, 0.0, 30.0),
    "site_alpha":     (47.0, 1.5, 19.0),
    "site_bravo":     (-43.0, 0.0, 13.0),
    "overlook":       (18.0, 3.0, 16.0),
    "cable_run":      (29.0, 0.0, -18.0),
    "loading_dock":   (-40.0, 0.0, -16.0),
    "pump_corridor":  (-26.5, 0.0, 22.0),
    "ridge_walk":     (40.0, 0.0, 36.5),
    "back_hall":      (-30.0, 0.0, 44.0),
    # positions to hold around each site (pre-plant defence / post-plant guard)
    "alpha_hold_1":   (45.5, 1.5, 17.0),
    "alpha_hold_2":   (52.0, 1.5, 16.0),
    "alpha_hold_3":   (33.0, 0.0, 9.0),
    "bravo_hold_1":   (-38.0, 0.0, 9.0),
    "bravo_hold_2":   (-48.0, 0.0, 21.0),
    "bravo_hold_3":   (-34.0, 0.0, 17.0),
}

# Plant zone name -> nav key prefix ("site_<key>" is the plant point, "<key>_hold_N" guard spots)
SITE_KEYS = {"Site Alpha": "alpha", "Site Bravo": "bravo"}


def callout_at(x: float, z: float) -> str:
    for zone in CALLOUTS:
        if zone.contains(x, z):
            return zone.name
    return ""


def collision_boxes() -> list[AABB]:
    return [s.box for s in SOLIDS]
