"""Round economy (engine-independent).

All numbers come from [economy] in config.toml — nothing is hardcoded here.

Participants (Player, Bot, test dummies) expose:
    team: str, money: int, owned: set[str], vitals (armor, helmet, max_armor),
    optional on_purchase(item_id) callback.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Item:
    id: str
    name: str
    kind: str          # "weapon" | "armor" | "helmet"
    price: int


def build_catalog(cfg) -> dict[str, Item]:
    e = cfg.economy
    return {
        "rk9": Item("rk9", cfg.weapons.rk9.name, "weapon", e.rk9_price),
        "sd4": Item("sd4", cfg.weapons.sd4.name, "weapon", e.sd4_price),
        "armor": Item("armor", "Armor Vest", "armor", e.armor_price),
        "helmet": Item("helmet", "Helmet", "helmet", e.helmet_price),
    }


class Economy:
    TEAMS = ("attackers", "defenders")

    def __init__(self, cfg):
        self.cfg = cfg
        self.e = cfg.economy
        self.catalog = build_catalog(cfg)
        self.loss_streak = {t: 0 for t in self.TEAMS}

    # ------------------------------------------------------------ money
    def clamp(self, amount: int) -> int:
        return max(0, min(int(amount), self.e.max_money))

    def add(self, p, amount: int) -> None:
        p.money = self.clamp(p.money + amount)

    def start_match(self, participants) -> None:
        self.loss_streak = {t: 0 for t in self.TEAMS}
        for p in participants:
            p.money = self.clamp(self.e.start_money)

    def loss_bonus(self, team: str) -> int:
        ladder = self.e.loss_bonus_ladder
        return ladder[min(self.loss_streak[team], len(ladder) - 1)]

    def on_kill(self, attacker, victim) -> None:
        if attacker is None or victim is None or attacker is victim:
            return
        if attacker.team != victim.team:
            self.add(attacker, self.e.kill_reward)

    def on_round_end(self, winner: str, participants) -> None:
        """Winners get the win reward; losers get the loss-ladder bonus for their
        current streak, then the streak advances. A win resets the streak."""
        loser = "defenders" if winner == "attackers" else "attackers"
        bonus = self.loss_bonus(loser)
        for p in participants:
            self.add(p, self.e.round_win_reward if p.team == winner else bonus)
        self.loss_streak[winner] = 0
        self.loss_streak[loser] += 1

    # ------------------------------------------------------------ buying
    def owns(self, p, item_id: str) -> bool:
        item = self.catalog[item_id]
        if item.kind == "weapon":
            return item_id in p.owned
        if item.kind == "armor":
            return p.vitals.armor >= p.vitals.max_armor
        return bool(p.vitals.helmet)

    def purchase(self, p, item_id: str) -> str:
        """Returns 'bought', 'owned' (no charge) or 'poor'."""
        item = self.catalog[item_id]
        if self.owns(p, item_id):
            return "owned"
        if p.money < item.price:
            return "poor"
        p.money -= item.price
        if item.kind == "weapon":
            p.owned.add(item_id)
        elif item.kind == "armor":
            p.vitals.armor = p.vitals.max_armor
        else:
            p.vitals.helmet = True
        cb = getattr(p, "on_purchase", None)
        if cb:
            cb(item_id)
        return "bought"

    def auto_buy(self, p) -> list[str]:
        """Bot shopping list, using only catalog prices:
        rifle + armor (+ helmet) when affordable, otherwise sidearm + armor,
        otherwise whatever fits. Never overspends."""
        bought = []
        c = self.catalog
        rifle_kit = c["rk9"].price + c["armor"].price
        if "rk9" in p.owned or p.money >= rifle_kit:
            order = ["rk9", "armor", "helmet", "sd4"]
        else:
            order = ["sd4", "armor", "helmet"]
        for item_id in order:
            if self.purchase(p, item_id) == "bought":
                bought.append(item_id)
        return bought
