"""The player's weapons: slot switching, trigger handling, reload, firing.

Keys: 1/2/3 select a slot (mouse wheel cycles), R reloads, F inspects, left mouse fires.
Switching cancels an in-progress reload and starts the new weapon's deploy.
"""
from __future__ import annotations

import random

from ursina import Entity, held_keys, mouse, time

from game.shooting import fire_hitscan, melee_swing
from game.viewmodel import ViewModel
from game.weapons import Stance, WeaponState


class Arsenal(Entity):
    def __init__(self, player, defs, combat, effects, hud, cfg):
        super().__init__(name="arsenal")
        self.player, self.combat, self.effects, self.hud, self.cfg = player, combat, effects, hud, cfg
        self.rng = random.Random()
        self.weapons = {d.slot: WeaponState(d, rng=self.rng) for d in defs.values()}
        self.viewmodel = ViewModel()
        self.slot = 1
        self._pressed = False          # fire pressed this frame (for semi-auto)
        self.require_mouse_lock = True # the smoke test turns this off
        self.input_blocked = False     # set while a menu has focus
        self.weapons_locked = False    # set during the buy freeze
        player.on_round_reset_callbacks.append(lambda survived: self.reset())
        player.on_purchase_callbacks.append(self._on_purchase)
        self.reset()

    # ------------------------------------------------------------------ state
    @property
    def current(self) -> WeaponState:
        return self.weapons[self.slot]

    def owned_slots(self) -> list[int]:
        return sorted(s for s, w in self.weapons.items() if w.d.id in self.player.owned)

    def owned_weapons(self) -> dict:
        return {s: self.weapons[s] for s in self.owned_slots()}

    def reset(self):
        """Full ammo for every weapon, best owned weapon out (spawn / new round)."""
        for w in self.weapons.values():
            w.mag, w.reserve = w.d.mag_size, w.d.reserve
            w.recoil_up = w.recoil_side = w.bloom = 0.0
            w.reload_left = w.cooldown = 0.0
        self.switch(self.owned_slots()[0], force=True)

    def _on_purchase(self, item_id: str):
        for s, w in self.weapons.items():
            if w.d.id == item_id:
                w.mag, w.reserve = w.d.mag_size, w.d.reserve
                self.switch(s, force=True)

    def switch(self, slot: int, force: bool = False):
        if slot not in self.owned_slots() or (slot == self.slot and not force):
            return
        self.current.holster()
        self.slot = slot
        self.current.deploy()
        self.viewmodel.show(slot, self.current.d.deploy_time)

    # ------------------------------------------------------------------ input
    def input(self, key):
        if not self.player.alive or self.input_blocked:
            return
        if key in ("1", "2", "3"):
            self.switch(int(key))
        elif key == "scroll up" or key == "scroll down":
            slots = self.owned_slots()
            i = slots.index(self.slot) + (1 if key == "scroll down" else -1)
            self.switch(slots[i % len(slots)])
        elif key == "r":
            self.current.start_reload()
            self.viewmodel.reload()
        elif key == "f":
            self.viewmodel.inspect()
        elif key == "left mouse down" and (mouse.locked or not self.require_mouse_lock):
            self._pressed = True

    def stance(self) -> Stance:
        p = self.player
        return Stance(speed_fraction=p.horizontal_speed / self.cfg.movement.run_speed,
                      crouching=p.crouching, airborne=not p.body.grounded)

    def update(self):
        p, w = self.player, self.current
        for ws in self.weapons.values():
            ws.tick(time.dt)
        if w.d.id not in p.owned:                 # lost on death / new round
            self.switch(self.owned_slots()[0], force=True)
            w = self.current
        p.speed_multiplier = w.d.speed_multiplier
        ratio = w.d.view_kick_ratio
        p.view_recoil = (w.recoil_up * ratio, w.recoil_side * ratio)
        self.viewmodel.update_pose(p.horizontal_speed)
        self.viewmodel.enabled = p.alive

        pressed, self._pressed = self._pressed, False
        if self.weapons_locked or self.input_blocked:
            return
        if not (p.alive and p.controls_enabled and (mouse.locked or not self.require_mouse_lock)):
            return
        trigger = held_keys["left mouse"] and (w.d.automatic or pressed)
        if not trigger:
            return
        if w.ready():
            self._fire(w)
        elif not w.d.is_melee and w.mag == 0 and not w.reloading and pressed:
            w.start_reload()                     # dry trigger pull reloads

    # ------------------------------------------------------------------ firing
    def _fire(self, w: WeaponState):
        p = self.player
        eye = p.eye_position()
        if w.d.is_melee:
            w.fire(self.stance())
            self.viewmodel.swing()
            out = melee_swing(self.combat, p, w.d, eye, p.rotation_y, p.pitch)
        else:
            up, side = w.recoil_up, w.recoil_side          # recoil from previous shots
            spread = w.fire(self.stance())
            self.viewmodel.kick()
            out = fire_hitscan(self.combat, self.effects, p, w.d, eye,
                               p.rotation_y + side, p.pitch - up, spread, self.rng,
                               self.cfg.combat.spread.center_bias, self.viewmodel.muzzle_world())
            if w.mag == 0:
                w.start_reload()                           # auto-reload when emptied
        if out.hit_target is not None:
            self.hud.hitmarker(out.headshot, out.killed)
