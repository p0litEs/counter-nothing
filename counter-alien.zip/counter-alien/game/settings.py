"""Loads config.toml into attribute-style namespaces.

    from game.settings import CFG
    CFG.movement.run_speed
"""
from __future__ import annotations

import tomllib
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "config.toml"


def _to_ns(value):
    if isinstance(value, dict):
        return SimpleNamespace(**{k: _to_ns(v) for k, v in value.items()})
    return value


def load(path: Path = CONFIG_PATH) -> SimpleNamespace:
    with open(path, "rb") as f:
        return _to_ns(tomllib.load(f))


CFG = load()
