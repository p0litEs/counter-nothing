"""Engine-independent collision + movement physics.

The world is a list of axis-aligned boxes (AABBs). The player is also an AABB
(feet-centred). Movement is resolved one axis at a time, which is simple,
stable and fast enough in pure Python for ~150 boxes at 120 Hz.

Nothing here imports Ursina, so it can be unit-tested headless
(see tools/check_map.py).

Movement model (generic genre mechanics, written from first principles):
  * ground friction that scales with speed, with a "stop speed" floor
  * acceleration toward a wish direction, capped at a wish speed
  * weak air acceleration with a per-step cap
  * automatic step-up onto low ledges, and snap-down when walking off them
"""
from __future__ import annotations

import math
from dataclasses import dataclass

EPS = 1e-4


@dataclass(frozen=True, slots=True)
class AABB:
    x0: float
    y0: float
    z0: float
    x1: float
    y1: float
    z1: float

    def lo(self, axis: int) -> float:
        return (self.x0, self.y0, self.z0)[axis]

    def hi(self, axis: int) -> float:
        return (self.x1, self.y1, self.z1)[axis]


class CollisionWorld:
    def __init__(self, boxes):
        self.boxes: list[AABB] = list(boxes)

    def query(self, x0, y0, z0, x1, y1, z1, boxes=None) -> list[AABB]:
        """All boxes that strictly overlap the given region."""
        src = self.boxes if boxes is None else boxes
        return [b for b in src
                if b.x0 < x1 and b.x1 > x0
                and b.y0 < y1 and b.y1 > y0
                and b.z0 < z1 and b.z1 > z0]


class KinematicBody:
    """A feet-centred box that moves through a CollisionWorld."""

    def __init__(self, world: CollisionWorld, pos, radius: float,
                 height: float, step_height: float):
        self.world = world
        self.pos = [float(pos[0]), float(pos[1]), float(pos[2])]
        self.vel = [0.0, 0.0, 0.0]
        self.radius = radius
        self.height = height
        self.step_height = step_height
        self.grounded = False
        self.last_step_up = 0.0     # height of the most recent step-up (for camera smoothing)
        self._near: list[AABB] = world.boxes

    # ------------------------------------------------------------------ queries
    def hits_at(self, x, y, z, height=None, boxes=None) -> list[AABB]:
        r = self.radius
        h = self.height if height is None else height
        return self.world.query(x - r, y, z - r, x + r, y + h, z + r,
                                boxes if boxes is not None else self._near)

    def fits(self, x, y, z, height=None) -> bool:
        return not self.hits_at(x, y, z, height, self.world.boxes)

    # ------------------------------------------------------------------ motion
    def move(self, dt: float) -> None:
        """Integrate velocity over dt, resolving collisions."""
        dx, dy, dz = (v * dt for v in self.vel)
        # Broad phase: only consider boxes near the swept volume this step.
        x, y, z = self.pos
        pad = self.radius + self.step_height + abs(dx) + abs(dz) + 0.1
        self._near = self.world.query(
            x - pad, y - abs(dy) - self.step_height - 0.1, z - pad,
            x + pad, y + self.height + abs(dy) + self.step_height + 0.1, z + pad)

        was_grounded = self.grounded
        self.grounded = False
        self.last_step_up = 0.0

        self._move_vertical(dy)
        can_step = was_grounded or self.grounded
        self._move_horizontal(0, dx, can_step)
        self._move_horizontal(2, dz, can_step)

        # Snap down small drops (stairs) so we stay grounded while walking.
        if was_grounded and not self.grounded and self.vel[1] <= 0.0:
            x, y, z = self.pos
            below = self.world.query(x - self.radius, y - self.step_height, z - self.radius,
                                     x + self.radius, y, z + self.radius, self._near)
            if below:
                top = max(b.y1 for b in below)
                if top <= y + EPS:
                    self.pos[1] = top
                    self.vel[1] = 0.0
                    self.grounded = True

        # Ground probe: standing exactly on a surface counts as grounded.
        if not self.grounded and self.vel[1] <= 0.0:
            x, y, z = self.pos
            if self.world.query(x - self.radius, y - 0.02, z - self.radius,
                                x + self.radius, y, z + self.radius, self._near):
                self.grounded = True

    def _move_vertical(self, dy: float) -> None:
        if dy == 0.0:
            return
        self.pos[1] += dy
        hits = self.hits_at(*self.pos)
        if not hits:
            return
        if dy < 0:
            self.pos[1] = max(b.y1 for b in hits)
            self.grounded = True
        else:
            self.pos[1] = min(b.y0 for b in hits) - self.height - EPS
        self.vel[1] = 0.0

    def _move_horizontal(self, axis: int, d: float, can_step: bool) -> None:
        if d == 0.0:
            return
        self.pos[axis] += d
        hits = self.hits_at(*self.pos)
        if not hits:
            return
        if can_step:
            top = max(b.y1 for b in hits)
            rise = top - self.pos[1]
            if 0.0 < rise <= self.step_height and not self.hits_at(self.pos[0], top + EPS, self.pos[2]):
                self.pos[1] = top
                self.last_step_up = rise
                self.grounded = True
                return
        if d > 0:
            self.pos[axis] = min(b.lo(axis) for b in hits) - self.radius - EPS
        else:
            self.pos[axis] = max(b.hi(axis) for b in hits) + self.radius + EPS
        self.vel[axis] = 0.0


# --------------------------------------------------------------------------- #
#  Velocity helpers (pure functions on the body's velocity)
# --------------------------------------------------------------------------- #
def apply_friction(vel, dt: float, friction: float, stop_speed: float) -> None:
    speed = math.hypot(vel[0], vel[2])
    if speed < 1e-3:
        vel[0] = vel[2] = 0.0
        return
    drop = max(speed, stop_speed) * friction * dt
    scale = max(speed - drop, 0.0) / speed
    vel[0] *= scale
    vel[2] *= scale


def accelerate(vel, wish_dir, wish_speed: float, accel: float, dt: float,
               add_cap: float | None = None) -> None:
    """Add velocity toward wish_dir (unit xz vector) without exceeding wish_speed
    along that direction. add_cap limits the projected target (used in air)."""
    target = wish_speed if add_cap is None else min(wish_speed, add_cap)
    current = vel[0] * wish_dir[0] + vel[2] * wish_dir[1]
    add = target - current
    if add <= 0.0:
        return
    step = min(accel * wish_speed * dt, add)
    vel[0] += step * wish_dir[0]
    vel[2] += step * wish_dir[1]
