"""First-person controller: mouse look, fixed-step movement, crouch, jump.

Physics runs at CFG.movement.physics_hz in fixed sub-steps (see game/physics.py);
the camera is interpolated between steps so motion stays smooth at any FPS.
"""
from __future__ import annotations

import math

from ursina import Entity, Vec3, camera, held_keys, mouse, time

from game.combat import Vitals, standard_hitboxes
from game.physics import KinematicBody, accelerate, apply_friction


class Player(Entity):
    def __init__(self, world, cfg, team: str = "attackers"):
        super().__init__(name="player")
        self.cfg = cfg
        self.world = world
        self.team = team
        p = cfg.player
        self.body = KinematicBody(world.collision, (0, 0, 0), p.radius, p.stand_height, p.step_height)

        self.head = Entity(parent=self, y=p.stand_eye)
        camera.parent = self.head
        camera.position = Vec3(0, 0, 0)
        camera.rotation = Vec3(0, 0, 0)
        camera.fov = cfg.window.fov
        camera.clip_plane_near = 0.05

        self.pitch = 0.0
        self.crouching = False
        self.eye = p.stand_eye
        self.step_offset = 0.0       # camera lag after a step-up (smooths stairs)
        self.jump_timer = 0.0
        self._accum = 0.0
        self._prev = list(self.body.pos)
        self.speed_multiplier = 1.0  # set each frame by the Arsenal (weapon weight / Field Knife)
        self.view_recoil = (0.0, 0.0)  # (up, side) degrees of recoil the camera shows
        self.controls_enabled = True
        self.movement_locked = False   # buy freeze: look around, can't move
        self.round_speed_multiplier = 1.0  # flag carrier slowdown (set by the session)

        # Combatant interface (see game/combat.py)
        self.display_name = "You"
        self.alive = True
        self.vitals = Vitals(p.max_health, 0, False, p.max_health, p.max_armor)
        self.on_damage_callbacks = []   # fn(attacker, dmg)
        self.on_death_callbacks = []    # fn(attacker)
        self.on_round_reset_callbacks = []  # fn(survived)
        self.on_purchase_callbacks = []     # fn(item_id)

        # Round participant interface (see game/rounds.py / game/economy.py)
        self.is_bot = False
        self.money = 0
        self.owned = set(cfg.economy.free_loadout)
        self.respawn(team, 0)

    # ------------------------------------------------------------------ participant
    def feet_position(self):
        return tuple(self.body.pos)

    @property
    def interact_held(self) -> bool:
        return bool(self.alive and self.controls_enabled and held_keys["e"])

    def round_reset(self, spawn_index: int, survived: bool):
        if not (survived and self.cfg.economy.keep_weapons_if_alive):
            self.owned = set(self.cfg.economy.free_loadout)
        self.respawn(self.team, spawn_index)
        self.vitals.armor, self.vitals.helmet = 0, False
        for fn in self.on_round_reset_callbacks:
            fn(survived)

    def on_purchase(self, item_id: str):
        for fn in self.on_purchase_callbacks:
            fn(item_id)

    # ------------------------------------------------------------------ combatant
    def hitboxes(self):
        return standard_hitboxes(*self.body.pos, self.body.height, self.body.radius)

    def eye_position(self):
        x, y, z = self.body.pos
        return (x, y + self.eye, z)

    def on_damaged(self, attacker, dmg):
        for fn in self.on_damage_callbacks:
            fn(attacker, dmg)

    def on_killed(self, attacker):
        self.alive = False
        self.controls_enabled = False
        self.body.vel[0] = self.body.vel[2] = 0.0
        for fn in self.on_death_callbacks:
            fn(attacker)

    def max_speed(self) -> float:
        m = self.cfg.movement
        base = m.crouch_speed if self.crouching else (m.walk_speed if held_keys["left shift"] else m.run_speed)
        return base * self.speed_multiplier * self.round_speed_multiplier

    # ------------------------------------------------------------------ public
    def respawn(self, team: str, index: int = 0):
        self.team = team
        x, z, yaw = self.world.spawn(team, index)
        self.body.pos = [x, 0.0, z]
        self.body.vel = [0.0, 0.0, 0.0]
        self.body.height = self.cfg.player.stand_height
        self.crouching = False
        self.eye = self.cfg.player.stand_eye
        self.rotation_y = yaw
        self.pitch = 0.0
        self._prev = list(self.body.pos)
        self.position = Vec3(*self.body.pos)
        self.vitals.health = self.cfg.player.max_health
        self.alive = True
        self.controls_enabled = True

    @property
    def horizontal_speed(self) -> float:
        return math.hypot(self.body.vel[0], self.body.vel[2])

    # ------------------------------------------------------------------ input
    def input(self, key):
        if key == "space" and self.controls_enabled and not self.movement_locked:
            self.jump_timer = self.cfg.movement.jump_buffer

    def update(self):
        m, p = self.cfg.movement, self.cfg.player
        frame_dt = min(time.dt, 0.1)

        # --- mouse look (yaw on self, pitch on head)
        if mouse.locked and self.controls_enabled:
            sens = self.cfg.window.mouse_sensitivity
            self.rotation_y += mouse.velocity[0] * sens
            dy = mouse.velocity[1] * sens
            self.pitch += dy if self.cfg.window.invert_y else -dy
            self.pitch = max(-89.0, min(89.0, self.pitch))
        # camera shows part of the weapon recoil (bullets get the full amount)
        self.head.rotation_x = self.pitch - self.view_recoil[0]
        self.head.rotation_y = self.view_recoil[1]

        # --- wish direction / speed
        ix = iz = 0.0
        if self.controls_enabled and not self.movement_locked:
            iz = held_keys["w"] - held_keys["s"]
            ix = held_keys["d"] - held_keys["a"]
        fwd, right = self.forward, self.right
        wx = fwd.x * iz + right.x * ix
        wz = fwd.z * iz + right.z * ix
        mag = math.hypot(wx, wz)
        wish_dir = (wx / mag, wz / mag) if mag > 1e-6 else (0.0, 0.0)

        self._update_crouch(self.controls_enabled and (held_keys["left control"] or held_keys["c"]))
        if self.crouching:
            wish_speed = m.crouch_speed
        elif held_keys["left shift"]:
            wish_speed = m.walk_speed
        else:
            wish_speed = m.run_speed
        wish_speed = wish_speed * self.speed_multiplier * self.round_speed_multiplier if mag > 1e-6 else 0.0

        # --- fixed-step simulation
        step = 1.0 / m.physics_hz
        self._accum += frame_dt
        while self._accum >= step:
            self._prev = list(self.body.pos)
            self._step(step, wish_dir, wish_speed)
            self._accum -= step
        self.jump_timer = max(0.0, self.jump_timer - frame_dt)

        # --- fell out of the world (should not happen) -> respawn
        if self.body.pos[1] < -20:
            self.respawn(self.team)

        # --- visuals: interpolate position, blend eye height, smooth steps
        a = self._accum / step
        self.position = Vec3(*(pv + (cv - pv) * a for pv, cv in zip(self._prev, self.body.pos)))
        target_eye = p.crouch_eye if self.crouching else p.stand_eye
        rate = (p.stand_eye - p.crouch_eye) / max(p.crouch_transition, 1e-3)
        if self.eye < target_eye:
            self.eye = min(target_eye, self.eye + rate * frame_dt)
        else:
            self.eye = max(target_eye, self.eye - rate * frame_dt)
        self.step_offset *= math.exp(-14.0 * frame_dt)
        self.head.y = self.eye + self.step_offset

    # ------------------------------------------------------------------ internals
    def _step(self, dt, wish_dir, wish_speed):
        m = self.cfg.movement
        b = self.body
        if self.jump_timer > 0.0 and b.grounded:
            b.vel[1] = m.jump_velocity
            b.grounded = False
            self.jump_timer = 0.0
        if b.grounded:
            apply_friction(b.vel, dt, m.friction, m.stop_speed)
            if wish_speed > 0:
                accelerate(b.vel, wish_dir, wish_speed, m.ground_accel, dt)
        elif wish_speed > 0:
            accelerate(b.vel, wish_dir, wish_speed, m.air_accel, dt, add_cap=m.air_speed_cap)
        b.vel[1] = max(b.vel[1] - m.gravity * dt, -m.terminal_velocity)
        b.move(dt)
        if b.last_step_up > 0:
            self.step_offset -= b.last_step_up

    def _update_crouch(self, want: bool):
        p = self.cfg.player
        b = self.body
        diff = p.stand_height - p.crouch_height
        x, y, z = b.pos
        if want and not self.crouching:
            # Mid-air crouch tucks the legs up (keeps the head where it was).
            if not b.grounded and b.fits(x, y + diff, z, p.crouch_height):
                b.pos[1] += diff
                self._prev[1] += diff
                self.eye -= diff
            b.height = p.crouch_height
            self.crouching = True
        elif not want and self.crouching:
            if not b.grounded and b.fits(x, y - diff, z, p.stand_height):
                b.pos[1] -= diff
                self._prev[1] -= diff
                self.eye += diff
            elif not b.fits(x, y, z, p.stand_height):
                return                          # no headroom: stay crouched
            b.height = p.stand_height
            self.crouching = False
