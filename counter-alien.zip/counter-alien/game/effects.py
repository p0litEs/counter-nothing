"""Placeholder visual effects: tracers, impact puffs, muzzle flashes.

All are short-lived primitive entities with original colours. No sprites or
sounds are loaded (the game is silent in Phase 2).
"""
from __future__ import annotations

from ursina import Entity, Vec3, color, destroy
from ursina.shaders import unlit_shader

TRACER = color.rgba(1.0, 0.95, 0.70, 0.85)
IMPACT = color.rgba(0.85, 0.85, 0.80, 1)
FLASH = color.rgba(1.0, 0.72, 0.25, 1)


class Effects:
    def tracer(self, start, end, col=TRACER, life: float = 0.05):
        s, e = Vec3(*start), Vec3(*end)
        length = (e - s).length()
        if length < 0.05:
            return
        t = Entity(model="cube", position=(s + e) / 2, scale=(0.025, 0.025, length),
                   color=col, shader=unlit_shader)
        t.look_at(e)
        destroy(t, delay=life)

    def impact(self, point, life: float = 0.35):
        p = Entity(model="cube", position=Vec3(*point), scale=0.09, color=IMPACT, shader=unlit_shader)
        p.animate_scale(0.02, duration=life)
        destroy(p, delay=life)

    def flash(self, point, size: float = 0.35, life: float = 0.04):
        f = Entity(model="quad", position=Vec3(*point), scale=size, color=FLASH,
                   billboard=True, shader=unlit_shader, rotation_z=45)
        destroy(f, delay=life)
