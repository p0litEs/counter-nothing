"""Bot navigation: a 2.5D grid graph plus cached flow fields.

The map is sampled on a regular grid. Each cell can hold several standing
surfaces (e.g. the floor under the Gantry and the Gantry deck itself), so a
node is (cell, height). Edges connect neighbouring nodes when a bot can walk
between them: step up at most step_height, or drop down at most max_drop.

Instead of running A* per bot, we compute a *flow field* per named goal once
(reverse Dijkstra from the goal). Any bot anywhere then just walks "downhill"
toward lower distance. Phase 3 can add objective goals (plant spots etc.) by
registering more named points — no bot code changes needed.

Pure Python, no engine imports.
"""
from __future__ import annotations

import heapq
import math

from game.physics import CollisionWorld

INF = float("inf")
NEIGHBOURS = ((1, 0, 1.0), (-1, 0, 1.0), (0, 1, 1.0), (0, -1, 1.0),
              (1, 1, math.sqrt(2)), (1, -1, math.sqrt(2)), (-1, 1, math.sqrt(2)), (-1, -1, math.sqrt(2)))


class NavGrid:
    def __init__(self, world: CollisionWorld, bounds, cell: float, radius: float,
                 height: float, step: float, max_drop: float):
        self.world = world
        self.x0, self.z0, x1, z1 = bounds
        self.cell = cell
        self.nx = int((x1 - self.x0) / cell)
        self.nz = int((z1 - self.z0) / cell)
        self.step = step
        self.max_drop = max_drop

        # Spatial buckets so each cell only tests nearby boxes.
        bucket = 8.0
        self._bucket = bucket
        buckets: dict[tuple[int, int], list] = {}
        for b in world.boxes:
            for bx in range(int((b.x0 - self.x0) // bucket), int((b.x1 - self.x0) // bucket) + 1):
                for bz in range(int((b.z0 - self.z0) // bucket), int((b.z1 - self.z0) // bucket) + 1):
                    buckets.setdefault((bx, bz), []).append(b)

        # --- nodes
        self.nodes: list[tuple[int, int, float]] = []
        self.cell_nodes: dict[tuple[int, int], list[int]] = {}
        for ix in range(self.nx):
            for iz in range(self.nz):
                cx, cz = self.center(ix, iz)
                near = buckets.get((int((cx - self.x0) // bucket), int((cz - self.z0) // bucket)), [])
                col = world.query(cx - radius, -2, cz - radius, cx + radius, 100, cz + radius, near)
                ids = []
                for h in sorted({b.y1 for b in col}):
                    if not world.query(cx - radius, h + 1e-3, cz - radius,
                                       cx + radius, h + height, cz + radius, col):
                        ids.append(len(self.nodes))
                        self.nodes.append((ix, iz, h))
                if ids:
                    self.cell_nodes[(ix, iz)] = ids

        # --- edges (forward and reverse)
        self.out_edges: list[list[tuple[int, float]]] = [[] for _ in self.nodes]
        self.in_edges: list[list[tuple[int, float]]] = [[] for _ in self.nodes]
        for nid, (ix, iz, h) in enumerate(self.nodes):
            for dx, dz, cost in NEIGHBOURS:
                targets = self.cell_nodes.get((ix + dx, iz + dz))
                if not targets:
                    continue
                for tid in targets:
                    h2 = self.nodes[tid][2]
                    if not self._walkable(h, h2):
                        continue
                    if dx and dz and not (self._has_level(ix + dx, iz, h, h2)
                                          and self._has_level(ix, iz + dz, h, h2)):
                        continue                       # no corner cutting
                    self.out_edges[nid].append((tid, cost))
                    self.in_edges[tid].append((nid, cost))

        self._fields: dict[str, list[float]] = {}
        self._dynamic: dict[str, tuple] = {}

    # ------------------------------------------------------------------ geometry
    def center(self, ix: int, iz: int) -> tuple[float, float]:
        return self.x0 + (ix + 0.5) * self.cell, self.z0 + (iz + 0.5) * self.cell

    def node_pos(self, nid: int) -> tuple[float, float, float]:
        ix, iz, h = self.nodes[nid]
        x, z = self.center(ix, iz)
        return x, h, z

    def _walkable(self, h: float, h2: float) -> bool:
        return -self.max_drop <= h2 - h <= self.step + 1e-6

    def _has_level(self, ix, iz, h, h2) -> bool:
        lo, hi = min(h, h2) - 0.05, max(h, h2) + 0.05
        return any(lo <= self.nodes[n][2] <= hi for n in self.cell_nodes.get((ix, iz), ()))

    def node_at(self, x: float, y: float, z: float, search: int = 1) -> int | None:
        """Nearest node to a world position (same cell first, then a small ring)."""
        ix = int((x - self.x0) / self.cell)
        iz = int((z - self.z0) / self.cell)
        best, best_d = None, INF
        for r in range(search + 1):
            for jx in range(ix - r, ix + r + 1):
                for jz in range(iz - r, iz + r + 1):
                    if r and max(abs(jx - ix), abs(jz - iz)) != r:
                        continue
                    for nid in self.cell_nodes.get((jx, jz), ()):
                        nh = self.nodes[nid][2]
                        if nh > y + 0.6:
                            continue
                        cx, cz = self.center(jx, jz)
                        d = (cx - x) ** 2 + (cz - z) ** 2 + (nh - y) ** 2 * 4
                        if d < best_d:
                            best, best_d = nid, d
            if best is not None:
                return best
        return None

    # ------------------------------------------------------------------ fields
    def build_field(self, name: str, goal: tuple[float, float, float]) -> list[float]:
        """Reverse Dijkstra: dist[n] = walking cost from n to the goal."""
        start = self.node_at(*goal, search=3)
        dist = [INF] * len(self.nodes)
        if start is None:
            self._fields[name] = dist
            return dist
        dist[start] = 0.0
        heap = [(0.0, start)]
        while heap:
            d, n = heapq.heappop(heap)
            if d > dist[n]:
                continue
            for prev, cost in self.in_edges[n]:
                nd = d + cost
                if nd < dist[prev]:
                    dist[prev] = nd
                    heapq.heappush(heap, (nd, prev))
        self._fields[name] = dist
        return dist

    def field(self, name: str) -> list[float] | None:
        return self._fields.get(name)

    def dynamic_field(self, key: str, point, now: float, max_age: float = 2.0,
                      move_tolerance: float = 1.5) -> list[float]:
        """Field toward a moving point (dropped flag, flag carrier, planted flag).
        Shared by every bot using the same key; rebuilt only when the point has
        moved more than move_tolerance or the field is older than max_age."""
        cached = self._dynamic.get(key)
        if cached is not None:
            p, t, f = cached
            moved = math.dist(p, point)
            if moved <= move_tolerance and (now - t) <= max_age:
                return f
            if moved <= 0.05:            # static target: never rebuild
                return f
        f = self.build_field(key, point)
        self._dynamic[key] = (tuple(point), now, f)
        return f

    def clear_dynamic(self):
        for key in self._dynamic:
            self._fields.pop(key, None)
        self._dynamic.clear()

    def next_waypoint(self, nid: int, field: list[float], lookahead: int = 3):
        """Follow the field downhill for a few steps; returns a world point or None."""
        if field[nid] == INF:
            return None
        cur = nid
        for _ in range(lookahead):
            best, best_d = None, field[cur]
            for nxt, _cost in self.out_edges[cur]:
                if field[nxt] < best_d:
                    best, best_d = nxt, field[nxt]
            if best is None:
                break
            level_change = abs(self.nodes[best][2] - self.nodes[cur][2]) > 0.05
            if level_change and cur != nid:
                break                       # don't cut corners across steps/ledges
            cur = best
            if level_change:
                break
        return self.node_pos(cur)
