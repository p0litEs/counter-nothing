"""Combat + objective bots.

Layers (each replaceable on its own):
  BotDirector     per-round team plan: picks the attack site, assigns a BotRole
                  to every bot at round start and reassigns on plant.
  ObjectiveBrain  turns the bot's role + flag state into an Order each think
                  tick (where to go, how close, whether to hold E there).
  PatrolBrain     Phase 2 behaviour (wander between points of interest); used
                  when no RoundManager is attached.
  Bot             senses enemies, aims with reaction delay + error, fires
                  bursts, follows flow fields, plants / takes down, takes
                  damage, dies. Uses the same KinematicBody, WeaponState and
                  shot resolution as the player.

Fighting always has priority over the objective: a bot that sees an enemy
engages, then resumes its Order once the threat is gone.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass
from enum import Enum

from ursina import Entity, Text, Vec3, color, time
from ursina.shaders import lit_with_shadows_shader

from game.combat import Vitals, standard_hitboxes
from game.nav import INF
from game.physics import KinematicBody, accelerate, apply_friction
from game.rounds import ATTACKERS, DEFENDERS, FlagState, Phase
from game.shooting import fire_hitscan, melee_swing
from game.weapons import Stance, WeaponState, direction, yaw_pitch_to

TEAM_COLORS = {ATTACKERS: (0.20, 0.72, 0.72), DEFENDERS: (0.92, 0.42, 0.36)}
EYE = 1.6
WEAPON_PREFERENCE = ("rk9", "sd4", "knife")     # best first


def _turn(current: float, target: float, max_step: float) -> float:
    delta = (target - current + 180.0) % 360.0 - 180.0
    return current + max(-max_step, min(max_step, delta))


# --------------------------------------------------------------------------- #
#  Roles, orders, brains
# --------------------------------------------------------------------------- #
class BotRole(Enum):
    CARRIER = "carrier"          # attacker holding the flag: go plant it
    ESCORT = "escort"            # attacker: stay near the flag carrier
    SITE_HOLDER = "site_holder"  # defender: guard a site / attacker: push or guard plant
    RETAKER = "retaker"          # defender after plant: go take the flag down


@dataclass
class Order:
    field_key: str | None = None   # named or dynamic nav field to follow
    point: tuple | None = None     # target point for dynamic fields
    arrive: float = 2.0            # stop when within this path distance
    interact: bool = False         # hold E on arrival
    look_around: bool = True


class PatrolBrain:
    """Phase 2: wander between points of interest (free play without rounds)."""

    GOALS = {
        ATTACKERS: ["switchyard", "switchyard", "defender_spawn", "north_court", "cable_run",
                    "overlook", "site_alpha", "site_bravo", "pump_corridor", "loading_dock"],
        DEFENDERS: ["switchyard", "switchyard", "attacker_spawn", "site_alpha", "site_bravo",
                    "ridge_walk", "back_hall", "pump_corridor", "overlook", "cable_run"],
    }

    def __init__(self, team: str, rng: random.Random):
        self.team, self.rng, self.goal, self.idle_until = team, rng, None, 0.0

    def order(self, bot) -> Order:
        if self.goal is None or bot.arrived:
            if bot.arrived and bot.clock < self.idle_until:
                return Order(self.goal, arrive=INF)          # idle in place
            self.goal = self.rng.choice([g for g in self.GOALS[self.team] if g != self.goal])
            b = bot.cfg.bots
            self.idle_until = bot.clock + self.rng.uniform(b.idle_min, b.idle_max)
            bot.arrived = False
        return Order(self.goal)


class BotDirector:
    """Per-round team plan, shared by all bots."""

    def __init__(self, ctx, rng: random.Random):
        self.ctx, self.rng = ctx, rng
        self.target_site = "alpha"

    def site_keys(self) -> list[str]:
        return list(self.ctx.world.map.SITE_KEYS.values())

    def on_round_start(self, bots):
        rm = self.ctx.rounds
        self.target_site = self.rng.choice(self.site_keys())
        atk = [b for b in bots if b.team == ATTACKERS]
        dfn = [b for b in bots if b.team == DEFENDERS]
        others = [b for b in atk if b is not rm.flag.carrier]
        for b in atk:
            b.assigned_site = self.target_site
        if rm.flag.carrier in atk:
            rm.flag.carrier.role = BotRole.CARRIER
        for i, b in enumerate(others):          # alternate escorts and site pushers
            b.role = BotRole.ESCORT if i % 2 == 0 else BotRole.SITE_HOLDER
        sites = self.site_keys()
        for i, b in enumerate(dfn):
            b.role = BotRole.SITE_HOLDER
            b.assigned_site = sites[i % len(sites)]
        for b in bots:
            b.pick_hold_point()

    def on_plant(self, bots, site_name: str):
        key = self.ctx.world.map.SITE_KEYS[site_name]
        for b in bots:
            if b.team == ATTACKERS:
                b.role, b.assigned_site = BotRole.SITE_HOLDER, key
                b.pick_hold_point()
            else:
                b.role = BotRole.RETAKER


class ObjectiveBrain:
    """Phase 3: role + flag state -> Order."""

    def order(self, bot) -> Order:
        rm = bot.ctx.rounds
        f, fc = rm.flag, bot.cfg.flag
        if rm.phase != Phase.LIVE:
            return Order(None)
        carrier_is_bot = getattr(f.carrier, "is_bot", False)

        if bot.team == ATTACKERS:
            if f.state == FlagState.PLANTED:
                return Order(bot.hold_key(), arrive=1.5)
            if f.state == FlagState.DROPPED:
                return Order("flag", point=f.pos, arrive=0.0)
            if f.carrier is bot:
                bot.role = BotRole.CARRIER
                if rm.zone_for(bot) is not None:
                    return Order(f"site_{bot.assigned_site}", arrive=INF, interact=True)
                return Order(f"site_{bot.assigned_site}", arrive=0.5)
            if bot.role == BotRole.CARRIER:            # someone else picked it up
                bot.role = BotRole.ESCORT
            if bot.role == BotRole.ESCORT or not carrier_is_bot:
                return Order("carrier", point=f.pos, arrive=5.0)
            return Order(bot.hold_key(), arrive=1.5)   # site pusher

        # defenders
        if f.state == FlagState.PLANTED:
            bot.role = BotRole.RETAKER
            if rm.distance_to_flag(bot) <= fc.interact_radius * 0.8:
                return Order("flag", point=f.pos, arrive=INF, interact=True)
            return Order("flag", point=f.pos, arrive=0.0)
        if f.state == FlagState.CARRIED and not carrier_is_bot:
            return Order("carrier", point=f.pos, arrive=3.0)      # pursue the human carrier
        return Order(bot.hold_key(), arrive=1.5)


# --------------------------------------------------------------------------- #
#  Bot
# --------------------------------------------------------------------------- #
class Bot(Entity):
    def __init__(self, ctx, team: str, name: str, spawn_index: int):
        super().__init__(name=f"bot_{name}")
        self.ctx, self.cfg = ctx, ctx.cfg
        self.team, self.display_name = team, name
        self.rng = random.Random(sum(map(ord, name)) * 7919)
        p, bc = self.cfg.player, self.cfg.bots
        self.body = KinematicBody(ctx.world.collision, (0, 0, 0), p.radius, p.stand_height, p.step_height)
        self.vitals = Vitals(bc.health, 0, False, p.max_health, p.max_armor)
        self.weapons = {wid: WeaponState(d, infinite_reserve=bc.infinite_reserve, rng=self.rng)
                        for wid, d in ctx.defs.items()}
        self.brain = ObjectiveBrain() if ctx.rounds is not None else PatrolBrain(team, self.rng)
        self.alive = True
        self.frozen = False             # test hook: skip AI + physics
        self.hold_fire = False          # test hook: never shoot
        # round participant interface
        self.is_bot = True
        self.money = 0
        self.owned = set(self.cfg.economy.free_loadout)
        self.interact_held = False
        self.role = BotRole.SITE_HOLDER
        self.assigned_site = "alpha"
        self.hold_point = None
        self._weapon_id = None

        # visuals — simple original silhouette: slab torso, square head, visor stripe
        tc = TEAM_COLORS[team]
        body_col = color.rgba(*tc, 1)
        dark = color.rgba(tc[0] * 0.45, tc[1] * 0.45, tc[2] * 0.45, 1)
        sh = lit_with_shadows_shader
        Entity(parent=self, model="cube", position=(0, 0.45, 0), scale=(0.42, 0.9, 0.3), color=dark, shader=sh)
        Entity(parent=self, model="cube", position=(0, 1.15, 0), scale=(0.6, 0.62, 0.4), color=body_col, shader=sh)
        Entity(parent=self, model="cube", position=(0, 1.63, 0), scale=0.32, color=dark, shader=sh)
        Entity(parent=self, model="cube", position=(0, 1.66, 0.165), scale=(0.26, 0.07, 0.02),
               color=color.rgba(0.95, 0.85, 0.4, 1), shader=sh)
        self.gun = Entity(parent=self, model="cube", position=(0.22, 1.25, 0.35), scale=(0.08, 0.1, 0.6),
                          color=color.rgba(0.18, 0.19, 0.22, 1), shader=sh)
        self.muzzle = Entity(parent=self.gun, position=(0, 0, 0.55))
        self.tag = Text(parent=self, text=name, billboard=True, origin=(0, 0), y=2.15, scale=6,
                        color=color.rgba(*tc, 0.9))
        self.tag.enabled = getattr(bc, "show_names", True)

        self.respawn(spawn_index)

    # ------------------------------------------------------------ weapons
    @property
    def weapon(self) -> WeaponState:
        best = next(w for w in WEAPON_PREFERENCE if w in self.owned)
        if best != self._weapon_id:
            self._weapon_id = best
            self.weapons[best].deploy()
            self.gun.scale_z = 0.6 if best == "rk9" else (0.3 if best == "sd4" else 0.25)
        return self.weapons[best]

    def on_purchase(self, item_id: str):
        w = self.weapons.get(item_id)
        if w is not None:
            w.mag, w.reserve = w.d.mag_size, w.d.reserve

    # ------------------------------------------------------------ Combatant / participant
    def hitboxes(self):
        return standard_hitboxes(*self.body.pos, self.body.height, self.body.radius)

    def eye_position(self):
        x, y, z = self.body.pos
        return (x, y + EYE, z)

    def feet_position(self):
        return tuple(self.body.pos)

    @property
    def horizontal_speed(self) -> float:
        return math.hypot(self.body.vel[0], self.body.vel[2])

    def on_damaged(self, attacker, dmg):
        # Getting shot makes the bot turn toward the shooter.
        if attacker is not None and attacker.alive and self.target is None:
            self._acquire(attacker)

    def on_killed(self, attacker):
        self.alive = False
        self.visible = False
        self.interact_held = False      # loadout is cleared in round_reset (didn't survive)

    def round_reset(self, spawn_index: int, survived: bool):
        if not (survived and self.cfg.economy.keep_weapons_if_alive):
            self.owned = set(self.cfg.economy.free_loadout)
        self.respawn(spawn_index)
        self.vitals.armor, self.vitals.helmet = 0, False

    def hold_key(self) -> str:
        return self.hold_point or f"site_{self.assigned_site}"

    def pick_hold_point(self):
        prefix = f"{self.assigned_site}_hold_"
        options = [k for k in self.ctx.world.map.NAV_POINTS if k.startswith(prefix)]
        options.append(f"site_{self.assigned_site}")
        self.hold_point = self.rng.choice(options)
        self.hold_until = self.clock + self.rng.uniform(self.cfg.bots.hold_min, self.cfg.bots.hold_max)

    # ------------------------------------------------------------ lifecycle
    def respawn(self, index: int | None = None):
        pts = self.ctx.world.map.SPAWNS[self.team]
        x, z = pts[(index if index is not None else self.rng.randrange(len(pts))) % len(pts)]
        x += self.rng.uniform(-0.8, 0.8)
        z += self.rng.uniform(-0.8, 0.8)
        if not self.body.fits(x, 0.001, z):
            x, z = pts[0]
        self.body.pos = [x, 0.0, z]
        self.body.vel = [0.0, 0.0, 0.0]
        self.vitals.health = self.cfg.bots.health
        for w in self.weapons.values():
            w.mag, w.reserve, w.reload_left, w.cooldown = w.d.mag_size, w.d.reserve, 0.0, 0.0
            w.recoil_up = w.recoil_side = w.bloom = 0.0
        self._weapon_id = None
        self.alive = True
        self.visible = True
        self.yaw = self.ctx.world.map.SPAWN_YAW[self.team]
        self.pitch = 0.0
        self.target = None
        self.target_visible = False
        self.last_seen = -99.0
        self.last_seen_pos = None
        self.reaction = 0.0
        self.think_timer = self.rng.uniform(0, self.cfg.bots.think_interval)
        self.err = (0.0, 0.0)
        self.err_timer = 0.0
        self.burst_left = 0
        self.burst_pause = 0.0
        self.stuck_timer = 0.0
        self.last_progress_pos = (x, z)
        self.clock = 0.0
        self.hold_until = 0.0
        self.arrived = False
        self.order = Order(None)
        self.interact_held = False
        self.position = Vec3(*self.body.pos)

    # ------------------------------------------------------------ perception
    def _acquire(self, enemy):
        bc = self.cfg.bots
        self.target = enemy
        self.reaction = bc.reaction_time + self.rng.uniform(0, bc.reaction_jitter)
        self.burst_left = self.rng.randint(bc.burst_min, bc.burst_max)
        self.last_seen = self.clock
        self.last_seen_pos = enemy.eye_position()

    def _can_see(self, enemy) -> bool:
        bc = self.cfg.bots
        eye = self.eye_position()
        tgt = enemy.eye_position()
        dx, dy, dz = tgt[0] - eye[0], tgt[1] - eye[1], tgt[2] - eye[2]
        dist = math.sqrt(dx * dx + dy * dy + dz * dz)
        if dist > bc.vision_range:
            return False
        if dist > 4.0:
            yaw, _ = yaw_pitch_to(dx, dy, dz)
            if abs((yaw - self.yaw + 180) % 360 - 180) > bc.vision_fov / 2:
                return False
        cw = self.ctx.combat
        if cw.line_of_sight(eye, tgt):
            return True
        x, y, z = enemy.body.pos
        return cw.line_of_sight(eye, (x, y + 1.0, z))      # head hidden, torso visible

    def _think(self):
        enemies = [c for c in self.ctx.combat.combatants if c.alive and c.team != self.team]
        visible = [e for e in enemies if self._can_see(e)]
        if self.target is not None and (not self.target.alive):
            self.target = None
        if visible:
            ex, ey, ez = self.eye_position()
            nearest = min(visible, key=lambda e: sum((a - b) ** 2 for a, b in zip(e.eye_position(), (ex, ey, ez))))
            if self.target is None or (self.target not in visible):
                self._acquire(nearest)
            self.target_visible = True
            self.last_seen = self.clock
            self.last_seen_pos = self.target.eye_position()
        else:
            self.target_visible = False
            if self.target is not None and self.clock - self.last_seen > self.cfg.bots.memory_time:
                self.target = None
        # objective: refresh the order; rotate guard spots now and then
        if self.ctx.rounds is not None and self.arrived and self.clock > self.hold_until \
                and self.role == BotRole.SITE_HOLDER:
            self.pick_hold_point()
            self.arrived = False
        self.order = self.brain.order(self)

    # ------------------------------------------------------------ update
    def update(self):
        dt = min(time.dt, 0.1)
        if not self.alive or self.frozen:
            self.interact_held = False
            return
        rm = self.ctx.rounds
        self.clock += dt
        bc = self.cfg.bots
        w = self.weapon
        w.tick(dt)
        if rm is not None and rm.movement_locked:
            self.interact_held = False
            self._physics(dt, (0.0, 0.0), 0.0)
            self._sync_visuals()
            return
        self.think_timer -= dt
        if self.think_timer <= 0:
            self.think_timer = bc.think_interval
            self._think()

        self.interact_held = False
        if self.target is not None and not self.hold_fire:
            wish_dir, wish_speed = self._engage(dt)
        else:
            wish_dir, wish_speed = self._follow_order(dt)

        self._physics(dt, wish_dir, wish_speed)
        self._sync_visuals()

    def _sync_visuals(self):
        self.position = Vec3(*self.body.pos)
        self.rotation_y = self.yaw
        self.gun.rotation_x = self.pitch

    def _move_speed(self) -> float:
        mult = self.ctx.rounds.speed_multiplier(self) if self.ctx.rounds is not None else 1.0
        return self.cfg.movement.run_speed * self.cfg.bots.move_speed_scale * self.weapon.d.speed_multiplier * mult

    def _engage(self, dt):
        bc, w = self.cfg.bots, self.weapon
        self.reaction -= dt
        self.err_timer -= dt
        if self.err_timer <= 0:
            self.err_timer = bc.aim_error_reroll
            self.err = (self.rng.gauss(0, bc.aim_error_deg), self.rng.gauss(0, bc.aim_error_deg))
        # aim at the upper chest of the live position if visible, else last known
        if self.target_visible:
            x, y, z = self.target.body.pos
            aim_pt = (x, y + self.target.body.height - 0.45, z)
        else:
            aim_pt = self.last_seen_pos
        eye = self.eye_position()
        want_yaw, want_pitch = yaw_pitch_to(aim_pt[0] - eye[0], aim_pt[1] - eye[1], aim_pt[2] - eye[2])
        want_yaw += self.err[0]
        want_pitch += self.err[1]
        step = bc.turn_speed * dt
        self.yaw = _turn(self.yaw, want_yaw, step)
        self.pitch = max(-80, min(80, _turn(self.pitch, want_pitch, step)))
        dx, dz = aim_pt[0] - self.body.pos[0], aim_pt[2] - self.body.pos[2]
        dist = math.hypot(dx, dz)

        if w.d.is_melee:
            # knife only: close the distance and swing
            if self.target_visible and dist < w.d.range * 0.9 and w.ready() and self.reaction <= 0:
                w.fire(Stance())
                melee_swing(self.ctx.combat, self, w.d, eye, self.yaw, self.pitch)
            if dist < w.d.range * 0.6:
                return (0.0, 0.0), 0.0
            return (dx / max(dist, 1e-3), dz / max(dist, 1e-3)), self._move_speed()

        if w.mag == 0 and not w.reloading:
            w.start_reload()
        if self.burst_pause > 0:
            self.burst_pause -= dt
        aim_err = abs((want_yaw - self.yaw + 180) % 360 - 180) + abs(want_pitch - self.pitch)
        if (self.target_visible and self.reaction <= 0 and self.burst_pause <= 0
                and aim_err < bc.aim_tolerance_deg and w.ready()):
            self._shoot()
        # Stand still while fighting (best accuracy); walk toward last-known spot otherwise.
        if self.target_visible or dist < 1.0:
            return (0.0, 0.0), 0.0
        return (dx / dist, dz / dist), self.cfg.movement.walk_speed

    def _shoot(self):
        w, bc = self.weapon, self.cfg.bots
        cw = self.ctx.combat
        keep = 1.0 - bc.recoil_control
        yaw = self.yaw + w.recoil_side * keep
        pitch = self.pitch - w.recoil_up * keep
        # don't shoot through teammates
        probe = cw.raycast(self.eye_position(), direction(yaw, pitch), w.d.range, ignore=self)
        if probe is not None and probe.target is not None and probe.target.team == self.team:
            return
        stance = Stance(speed_fraction=self.horizontal_speed / self.cfg.movement.run_speed,
                        airborne=not self.body.grounded)
        spread = w.fire(stance)
        muzzle = tuple(self.muzzle.world_position)
        self.ctx.effects.flash(muzzle, 0.3)
        tc = TEAM_COLORS[self.team]
        fire_hitscan(cw, self.ctx.effects, self, w.d, self.eye_position(), yaw, pitch, spread,
                     self.rng, self.cfg.combat.spread.center_bias, muzzle,
                     tracer_color=color.rgba(*(0.6 + c * 0.4 for c in tc), 0.8))
        self.burst_left -= 1
        if self.burst_left <= 0:
            self.burst_pause = bc.burst_pause
            self.burst_left = self.rng.randint(bc.burst_min, bc.burst_max)

    def _follow_order(self, dt):
        """Walk the current Order's flow field; stand (and maybe hold E) on arrival."""
        o, nav = self.order, self.ctx.nav
        if o.field_key is None:
            return (0.0, 0.0), 0.0
        if o.point is not None:
            field = nav.dynamic_field(o.field_key, o.point, self.clock_global())
        else:
            field = nav.field(o.field_key)
        nid = nav.node_at(*self.body.pos)
        if field is None or nid is None or field[nid] == INF:
            return (0.0, 0.0), 0.0
        if field[nid] <= o.arrive or o.arrive == INF:
            self.arrived = True
            if o.interact:
                self.interact_held = True
            elif o.look_around:
                self.yaw += 35 * dt * (1 if (int(self.clock / 2) % 2) else -1)
            return (0.0, 0.0), 0.0
        self.arrived = False
        wp = nav.next_waypoint(nid, field)
        if wp is None:
            return (0.0, 0.0), 0.0
        dx, dz = wp[0] - self.body.pos[0], wp[2] - self.body.pos[2]
        if o.point is not None and field[nid] <= 1.5:          # last metre: aim at the exact point
            dx, dz = o.point[0] - self.body.pos[0], o.point[2] - self.body.pos[2]
        m = math.hypot(dx, dz)
        if m < 1e-3:
            return (0.0, 0.0), 0.0
        want_yaw, _ = yaw_pitch_to(dx, 0, dz)
        self.yaw = _turn(self.yaw, want_yaw, 240 * dt)
        self.pitch = _turn(self.pitch, 0.0, 120 * dt)
        # stuck detection: hop
        self.stuck_timer += dt
        if self.stuck_timer > 1.5:
            px, pz = self.last_progress_pos
            if math.hypot(self.body.pos[0] - px, self.body.pos[2] - pz) < 0.75 and self.body.grounded:
                self.body.vel[1] = self.cfg.movement.jump_velocity
            self.stuck_timer = 0.0
            self.last_progress_pos = (self.body.pos[0], self.body.pos[2])
        return (dx / m, dz / m), self._move_speed()

    @staticmethod
    def clock_global() -> float:
        return time.time()

    def _physics(self, dt, wish_dir, wish_speed):
        m = self.cfg.movement
        b = self.body
        step = 1.0 / 60.0
        n = max(1, round(dt / step))
        h = dt / n
        for _ in range(n):
            if b.grounded:
                apply_friction(b.vel, h, m.friction, m.stop_speed)
                if wish_speed > 0:
                    accelerate(b.vel, wish_dir, wish_speed, m.ground_accel, h)
            b.vel[1] = max(b.vel[1] - m.gravity * h, -m.terminal_velocity)
            b.move(h)
        if b.pos[1] < -20:
            self.respawn()


class BotContext:
    """Shared services bots need (passed instead of globals). `rounds` is the
    RoundManager (None = Phase 2 free play)."""

    def __init__(self, cfg, world, combat, nav, effects, defs, rounds=None):
        self.cfg, self.world, self.combat, self.nav, self.effects, self.defs = cfg, world, combat, nav, effects, defs
        self.rounds = rounds


def spawn_bots(ctx: BotContext, player_team: str) -> list[Bot]:
    bc = ctx.cfg.bots
    if not bc.enabled:
        return []
    other = DEFENDERS if player_team == ATTACKERS else ATTACKERS
    names = list(bc.names)
    bots = []
    # spawn index 0 is reserved for the player on their own side
    for i in range(bc.allies):
        bots.append(Bot(ctx, player_team, names[len(bots) % len(names)], i + 1))
    for i in range(bc.enemies):
        bots.append(Bot(ctx, other, names[len(bots) % len(names)], i))
    return bots
