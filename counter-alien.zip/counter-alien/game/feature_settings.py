"""Crosshair customization and screen effect settings."""
from __future__ import annotations

import json
import random
from pathlib import Path

from ursina import Button, Entity, Text, camera, color, mouse, time, window

from game.hud import CROSSHAIR_COLORS, MONO, DIM, INK, TEXT


ROOT = Path(__file__).resolve().parent.parent
SETTINGS_FILE = ROOT / "settings.json"
STYLES = ("Cross", "Dot", "Cross+Dot")


def load_feature_settings(defaults):
    try:
        saved = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        if not isinstance(saved, dict):
            return defaults.copy()
        result = defaults.copy()
        result.update(saved)
        return result
    except (OSError, json.JSONDecodeError, TypeError):
        return defaults.copy()


def save_feature_settings(settings):
    try:
        SETTINGS_FILE.write_text(json.dumps(settings, indent=2), encoding="utf-8")
    except OSError as error:
        print(f"Could not save settings: {error}")


class FilmGrain(Entity):
    def __init__(self, enabled=False):
        super().__init__(parent=camera.ui)
        self.speckles = []
        self.timer = 0.0
        for _ in range(120):
            speckle = Entity(parent=self, model="quad",
                             color=color.rgba(255, 255, 255, 8),
                             scale=(0.0025, 0.0025))
            self.speckles.append(speckle)
            self._randomize(speckle)
        self.enabled = enabled

    def _randomize(self, speckle):
        aspect = window.aspect_ratio
        speckle.position = (random.uniform(-aspect / 2, aspect / 2),
                            random.uniform(-0.5, 0.5), 0)

    def set_enabled(self, enabled):
        self.enabled = enabled

    def update(self):
        if not self.enabled:
            return
        self.timer += time.dt
        if self.timer >= 0.15:
            self.timer = 0
            for speckle in self.speckles:
                self._randomize(speckle)


class FeatureSettingsPanel(Entity):
    def __init__(self, hud, arsenal, buy_menu):
        super().__init__(name="feature_settings", parent=camera.ui)
        self.hud = hud
        self.arsenal = arsenal
        self.buy_menu = buy_menu
        self.is_open = False

        defaults = {
            "crosshair_color": hud.cross_settings["crosshair_color"],
            "size": hud.cross_settings["size"],
            "thickness": hud.cross_settings["thickness"],
            "gap": hud.cross_settings["gap"],
            "style": hud.cross_settings["style"],
            "dynamic": hud.cross_settings["dynamic"],
            "screen_static": False,
        }
        self.settings = load_feature_settings(defaults)
        if not 0.004 <= float(self.settings["size"]) <= 0.06:
            self.settings["size"] = defaults["size"]

        self.panel = Entity(parent=self, model="quad", scale=(0.86, 0.78),
                            color=color.rgba(15, 19, 24, 245), z=0.02)
        Text(parent=self, text="SETTINGS", font=MONO, position=(-0.36, 0.31),
             scale=1.5, origin=(-0.5, 0.5), color=TEXT)

        self.preview = Entity(parent=self)
        self.preview_parts = []
        for _ in range(5):
            self.preview_parts.append(Entity(parent=self.preview, model="quad",
                                             scale=(0.01, 0.01),
                                             color=CROSSHAIR_COLORS["Green"]))
        self.preview.position = (0.22, 0.10)

        self.labels = {}
        rows = (
            ("Color", 0.00, "crosshair_color", tuple(CROSSHAIR_COLORS)),
            ("Size", -0.10, "size", None),
            ("Thickness", -0.20, "thickness", None),
            ("Gap", -0.30, "gap", None),
            ("Style", -0.40, "style", STYLES),
            ("Dynamic", -0.50, "dynamic", None),
            ("Screen Static", -0.60, "screen_static", None),
        )
        for title, y, key, options in rows:
            Text(parent=self, text=title, font=MONO, position=(-0.36, y),
                 scale=0.85, origin=(-0.5, 0.5), color=TEXT)
            Button(parent=self, text="Prev", position=(-0.05, y),
                   scale=(0.10, 0.05),
                   on_click=lambda k=key, o=options: self.change(k, -1, o))
            self.labels[key] = Text(parent=self, text="", font=MONO,
                                    position=(0.08, y), scale=0.8,
                                    origin=(-0.5, 0.5), color=TEXT)
            Button(parent=self, text=">", position=(0.30, y),
                   scale=(0.07, 0.05),
                   on_click=lambda k=key, o=options: self.change(k, 1, o))

        Button(parent=self, text="Back", position=(0.22, -0.70),
               scale=(0.20, 0.06), on_click=self.close)
        self.grain = FilmGrain(bool(self.settings["screen_static"]))
        self.enabled = False
        hud.apply_crosshair_settings(self.settings)
        self.refresh()

    def change(self, key, direction, options):
        if options:
            values = list(options)
            current = self.settings[key]
            index = values.index(current) if current in values else 0
            self.settings[key] = values[(index + direction) % len(values)]
        elif key in ("dynamic", "screen_static"):
            self.settings[key] = not self.settings[key]
        else:
            step = {"size": 0.002, "thickness": 0.0005, "gap": 0.001}[key]
            maximum = 0.06 if key == "size" else (0.012 if key == "thickness" else 0.04)
            minimum = 0.004 if key == "size" else (0.001 if key == "thickness" else 0.0)
            self.settings[key] = round(min(maximum, max(minimum,
                                                        float(self.settings[key]) + direction * step)), 4)

        save_feature_settings(self.settings)
        self.hud.apply_crosshair_settings(self.settings)
        self.grain.set_enabled(bool(self.settings["screen_static"]))
        self.refresh()

    def refresh(self):
        for key, label in self.labels.items():
            value = self.settings[key]
            if key in ("dynamic", "screen_static"):
                value = "On" if value else "Off"
            elif key in ("size", "thickness", "gap"):
                value = f"{float(value):.4f}"
            label.text = str(value)
        self.update_preview()

    def update_preview(self):
        aspect = window.aspect_ratio
        length = max(0.004, min(float(self.settings["size"]), 0.06))
        thickness = max(0.001, min(float(self.settings["thickness"]), 0.012))
        gap = max(0.0, min(float(self.settings["gap"]), 0.04))
        col = CROSSHAIR_COLORS.get(self.settings["crosshair_color"], CROSSHAIR_COLORS["Green"])
        bars = self.preview_parts[:4]
        dot = self.preview_parts[4]
        positions = (
            (-((gap + length / 2) * aspect), 0),
            (((gap + length / 2) * aspect), 0),
            (0, -(gap + length / 2)),
            (0, (gap + length / 2)),
        )
        for index, bar in enumerate(bars):
            bar.position = (*positions[index], 0)
            bar.scale = ((length * aspect, thickness) if index < 2 else
                         (thickness * aspect, length))
            bar.color = col
        dot.position = (0, 0, 0)
        dot.scale = (thickness * aspect * 1.5, thickness * 1.5)
        dot.color = col
        style = self.settings["style"]
        for bar in bars:
            bar.enabled = style in ("Cross", "Cross+Dot")
        dot.enabled = style in ("Dot", "Cross+Dot")

    def open(self):
        if self.buy_menu.is_open:
            self.buy_menu.close(relock=False)
        self.is_open = True
        self.enabled = True
        mouse.locked = False
        self.arsenal.input_blocked = True

    def close(self, relock=True):
        self.is_open = False
        self.enabled = False
        self.arsenal.input_blocked = False
        if relock:
            mouse.locked = True
