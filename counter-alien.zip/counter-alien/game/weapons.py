"""Data-driven weapons: definitions loaded from config.toml + runtime state.

Engine-independent. Both the player and bots own WeaponState objects; the
same spread/recoil/ammo rules apply to everyone.

Spread model (degrees, cone half-angle):
    base   = spread_crouch if crouching else spread_stand
    + spread_move * speed_fraction        (moving costs accuracy)
    + spread_air if airborne              (jumping is worst)
    + bloom                               (grows per shot, recovers over time)
The first shot after a pause has zero bloom, so it is as accurate as the
stance allows.

Recoil model: each shot kicks the aim up (growing for the first shots of a
spray, capped) and drifts it sideways along a smooth weapon-specific wave.
When the trigger rests, the offset decays back to zero exponentially.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, fields


@dataclass(frozen=True)
class WeaponDefinition:
    id: str
    name: str
    slot: int
    kind: str                      # "hitscan" | "melee"
    damage: float
    rpm: float
    deploy_time: float
    range: float
    speed_multiplier: float
    automatic: bool = False
    mag_size: int = 0
    reserve: int = 0
    reload_time: float = 0.0
    falloff_per_10m: float = 1.0
    spread_stand: float = 0.0
    spread_crouch: float = 0.0
    spread_move: float = 0.0
    spread_air: float = 0.0
    bloom_per_shot: float = 0.0
    bloom_max: float = 0.0
    bloom_recovery: float = 0.0
    recoil_vertical: float = 0.0
    recoil_vertical_growth: float = 0.0
    recoil_vertical_max: float = 0.0
    recoil_horizontal: float = 0.0
    recoil_recovery: float = 0.0
    view_kick_ratio: float = 0.5
    melee_arc: float = 0.0

    @property
    def fire_interval(self) -> float:
        return 60.0 / self.rpm

    @property
    def is_melee(self) -> bool:
        return self.kind == "melee"


def load_definitions(cfg) -> dict[str, WeaponDefinition]:
    """Build WeaponDefinitions from the [weapons.*] tables in config.toml."""
    allowed = {f.name for f in fields(WeaponDefinition)}
    defs = {}
    for wid, table in vars(cfg.weapons).items():
        data = {k: v for k, v in vars(table).items() if k in allowed}
        defs[wid] = WeaponDefinition(id=wid, **data)
    return defs


@dataclass
class Stance:
    speed_fraction: float = 0.0    # horizontal speed / base run speed
    crouching: bool = False
    airborne: bool = False


class WeaponState:
    """Ammo, timers, bloom and recoil for one carried weapon."""

    def __init__(self, definition: WeaponDefinition, infinite_reserve: bool = False,
                 rng: random.Random | None = None):
        self.d = definition
        self.mag = definition.mag_size
        self.reserve = definition.reserve
        self.infinite_reserve = infinite_reserve
        self.cooldown = 0.0
        self.reload_left = 0.0
        self.deploy_left = 0.0
        self.bloom = 0.0
        self.spray_index = 0
        self.since_shot = 99.0
        self.recoil_up = 0.0           # degrees, positive = aim pushed up
        self.recoil_side = 0.0         # degrees, positive = aim pushed right
        self.rng = rng or random.Random()
        self._phase = (sum(map(ord, definition.id)) % 628) / 100.0   # per-weapon wave phase

    # ------------------------------------------------------------ status
    @property
    def reloading(self) -> bool:
        return self.reload_left > 0.0

    @property
    def deploying(self) -> bool:
        return self.deploy_left > 0.0

    def ready(self) -> bool:
        if self.cooldown > 0 or self.reloading or self.deploying:
            return False
        return self.d.is_melee or self.mag > 0

    # ------------------------------------------------------------ actions
    def deploy(self) -> None:
        """Called when this weapon becomes active."""
        self.deploy_left = self.d.deploy_time
        self.reload_left = 0.0

    def holster(self) -> None:
        """Called when switching away: an in-progress reload is cancelled."""
        self.reload_left = 0.0

    def start_reload(self) -> bool:
        d = self.d
        if d.is_melee or self.reloading or self.mag >= d.mag_size:
            return False
        if self.reserve <= 0 and not self.infinite_reserve:
            return False
        self.reload_left = d.reload_time
        return True

    def spread(self, stance: Stance) -> float:
        d = self.d
        s = d.spread_crouch if stance.crouching else d.spread_stand
        s += d.spread_move * max(0.0, min(stance.speed_fraction, 1.3))
        if stance.airborne:
            s += d.spread_air
        return s + self.bloom

    def fire(self, stance: Stance) -> float:
        """Consume one shot. Returns the spread (degrees) to use for THIS shot;
        bloom and recoil from the shot apply to the next one."""
        d = self.d
        spread = self.spread(stance) if not d.is_melee else 0.0
        self.cooldown = d.fire_interval
        self.since_shot = 0.0
        if d.is_melee:
            return 0.0
        self.mag -= 1
        # recoil
        i = self.spray_index
        kick = d.recoil_vertical * (1.0 + d.recoil_vertical_growth * min(i, 8))
        self.recoil_up = min(self.recoil_up + kick, d.recoil_vertical_max)
        wave = math.sin(i * 0.65 + self._phase) * min(1.0, i / 3.0)
        jitter = self.rng.uniform(-0.25, 0.25)
        self.recoil_side += d.recoil_horizontal * (wave + jitter)
        limit = d.recoil_horizontal * 6.0
        self.recoil_side = max(-limit, min(limit, self.recoil_side))
        # bloom
        self.bloom = min(self.bloom + d.bloom_per_shot, d.bloom_max)
        self.spray_index += 1
        return spread

    def tick(self, dt: float) -> None:
        d = self.d
        self.cooldown = max(0.0, self.cooldown - dt)
        self.deploy_left = max(0.0, self.deploy_left - dt)
        self.since_shot += dt
        if self.reload_left > 0.0:
            self.reload_left -= dt
            if self.reload_left <= 0.0:
                self.reload_left = 0.0
                need = d.mag_size - self.mag
                take = need if self.infinite_reserve else min(need, self.reserve)
                self.mag += take
                if not self.infinite_reserve:
                    self.reserve -= take
        if d.is_melee:
            return
        # recovery only once the trigger has rested a moment
        if self.since_shot > d.fire_interval + 0.04:
            k = math.exp(-d.recoil_recovery * dt)
            self.recoil_up *= k
            self.recoil_side *= k
            self.bloom = max(0.0, self.bloom - d.bloom_recovery * dt)
        if self.since_shot > 0.35:
            self.spray_index = 0


# --------------------------------------------------------------------------- #
#  Direction helpers (Ursina convention: yaw clockwise from +z, pitch + = down)
# --------------------------------------------------------------------------- #
def direction(yaw_deg: float, pitch_deg: float) -> tuple[float, float, float]:
    y, p = math.radians(yaw_deg), math.radians(pitch_deg)
    return (math.sin(y) * math.cos(p), -math.sin(p), math.cos(y) * math.cos(p))


def yaw_pitch_to(dx: float, dy: float, dz: float) -> tuple[float, float]:
    yaw = math.degrees(math.atan2(dx, dz))
    pitch = -math.degrees(math.atan2(dy, math.hypot(dx, dz)))
    return yaw, pitch


def apply_spread(yaw: float, pitch: float, spread_deg: float, rng: random.Random,
                 center_bias: float = 1.0) -> tuple[float, float]:
    """Random offset inside a cone of half-angle spread_deg."""
    if spread_deg <= 0:
        return yaw, pitch
    ang = rng.uniform(0.0, math.tau)
    r = spread_deg * (rng.random() ** center_bias)
    return yaw + math.cos(ang) * r, pitch + math.sin(ang) * r
