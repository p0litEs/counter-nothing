"""In-engine smoke test (python main.py --smoke DIR).

Runs a scripted sequence against the real game objects, saves screenshots to
DIR, prints one line per check, then exits with status 0 (all ok) or 1.
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

from panda3d.core import Filename
from ursina import Entity, application, held_keys, time


class SmokeTest(Entity):
    def __init__(self, app, out_dir, cfg, **objs):
        super().__init__(name="smoke")
        self.app, self.cfg = app, cfg
        self.out = Path(out_dir)
        self.out.mkdir(parents=True, exist_ok=True)
        self.o = objs
        self.results: list[tuple[bool, str]] = []
        self.wait = 0.3
        self.max_speed = 0.0
        self.track_speed = False
        self.kills = []
        objs["combat"].kill_listeners.append(lambda a, v, w, hs: self.kills.append((a, v, hs)))
        objs["arsenal"].require_mouse_lock = False
        objs["hud"].debug.visible = True
        self.script = self._script()

    # ------------------------------------------------------------ helpers
    def check(self, cond, msg):
        self.results.append((bool(cond), msg))
        print(("SMOKE ok   " if cond else "SMOKE FAIL ") + msg)
        sys.stdout.flush()

    def shot(self, name):
        self.app.win.saveScreenshot(Filename.fromOsSpecific(str(self.out / f"{name}.png")))

    def place(self, x, y, z, yaw, pitch=0.0):
        p = self.o["player"]
        p.body.pos = [x, y, z]
        p.body.vel = [0.0, 0.0, 0.0]
        p._prev = list(p.body.pos)
        p.rotation_y, p.pitch = yaw, pitch

    def park_bots(self, keep=None):
        """Take bots out of play (except `keep`, which is frozen as a target)."""
        for b in self.o["bots"]:
            if b is keep:
                b.frozen = True             # stands still, still shootable
                continue
            b.alive = False
            b.visible = False
            b.respawn_timer = 1e9

    def release_bots(self):
        for b in self.o["bots"]:
            b.frozen = False
            b.respawn()

    def update(self):
        p = self.o["player"]
        if self.track_speed:
            self.max_speed = max(self.max_speed, p.horizontal_speed)
        self.wait -= time.dt
        if self.wait > 0:
            return
        try:
            self.wait = next(self.script)
        except StopIteration:
            ok = all(r[0] for r in self.results)
            print(f"SMOKE {'PASSED' if ok else 'FAILED'} ({sum(r[0] for r in self.results)}/{len(self.results)})")
            sys.stdout.flush()
            application.quit()
            sys.exit(0 if ok else 1)

    # ------------------------------------------------------------ script
    def _script(self):
        p, ars, bots, hud = self.o["player"], self.o["arsenal"], self.o["bots"], self.o["hud"]
        cfg = self.cfg
        rm = self.o["rounds"]
        from game.rounds import Phase
        # Part A (Phase 2 checks): pin the round in LIVE with no win conditions
        elim = cfg.round.elimination_wins
        cfg.round.elimination_wins = False
        rm.phase, rm.timer = Phase.LIVE, 1e9
        p.owned |= {"rk9", "sd4"}
        ars.reset()
        target = next(b for b in bots if b.team != p.team)
        self.park_bots(keep=target)
        target.respawn()
        target.vitals.armor = 100
        target.vitals.health = 50          # deterministic kill inside the 0.85 s spray
        target.body.pos = [-15.0, 0.0, -15.0]
        target.position = target.body.pos
        target.yaw = 180
        target.rotation_y = 180

        # ---- movement speed per weapon (knife boost) -------------------
        for slot, mult in ((3, cfg.weapons.knife.speed_multiplier), (1, cfg.weapons.rk9.speed_multiplier)):
            self.place(-17.5, 0, -32, 0)
            ars.switch(slot)
            yield 0.6
            self.max_speed, self.track_speed = 0.0, True
            held_keys["w"] = 1
            yield 2.2
            if slot == 3:
                self.shot("01_knife_running")
            held_keys["w"] = 0
            self.track_speed = False
            want = cfg.movement.run_speed * mult
            self.check(abs(self.max_speed - want) < 0.15,
                       f"slot {slot} top speed {self.max_speed:.2f} m/s (expected {want:.2f}, x{mult})")
            self.check(f"x{mult:.2f}" in hud.speed.text or mult == 1.0,
                       f"HUD speed readout shows multiplier: '{hud.speed.text}'")
            yield 0.4

        # ---- rifle spray at a frozen target -----------------------------
        self.place(-15, 0, -30, 0)
        eye_y = p.eye
        p.pitch = math.degrees(math.atan2(eye_y - 1.25, 15.0))      # aim at chest
        ars.switch(1)
        yield ars.current.d.deploy_time + 0.1
        start_armor = target.vitals.armor
        mag0 = ars.current.mag
        held_keys["left mouse"] = 1
        yield 0.35
        self.shot("02_rifle_spray")
        yield 0.5
        held_keys["left mouse"] = 0
        used = mag0 - ars.current.mag
        self.check(used >= 6, f"automatic fire used {used} rounds in 0.85 s")
        self.check(target.vitals.armor < start_armor or not target.alive,
                   f"target armor {start_armor:.0f} -> {target.vitals.armor:.0f} (absorbs damage)")
        self.check(not target.alive and any(v is target for _, v, _ in self.kills),
                   f"target eliminated by rifle (kill feed: '{hud.feed.text.splitlines()[-1] if hud.feed.text else ''}')")
        self.check(ars.current.recoil_up > 1.0, f"recoil climbed {ars.current.recoil_up:.1f} deg")
        yield 1.0
        self.check(ars.current.recoil_up < 0.3, f"recoil recovered to {ars.current.recoil_up:.2f} deg")

        # ---- reload, cancel on switch -------------------------------------
        mag_before, res_before = ars.current.mag, ars.current.reserve
        ars.input("r")
        yield 0.3
        ars.input("2")
        yield 0.1
        ars.input("1")
        yield ars.current.d.deploy_time + 0.1
        self.check(ars.weapons[1].mag == mag_before, "switching weapons cancelled the reload")
        ars.input("r")
        yield ars.current.d.reload_time + 0.2
        w = ars.weapons[1]
        self.check(w.mag == w.d.mag_size and w.reserve == res_before - (w.d.mag_size - mag_before),
                   f"reload complete: {w.mag}/{w.reserve}")

        # ---- sidearm is semi-automatic ----------------------------------------
        ars.switch(2)
        yield ars.current.d.deploy_time + 0.1
        m0 = ars.current.mag
        held_keys["left mouse"] = 1
        ars.input("left mouse down")
        yield 0.6
        held_keys["left mouse"] = 0
        self.check(m0 - ars.current.mag == 1, f"SD-4 fired {m0 - ars.current.mag} round per trigger pull")

        # ---- knife melee ------------------------------------------------------
        target.respawn()
        target.body.pos = [-15.0, 0.0, -28.6]
        target.position = target.body.pos
        self.place(-15, 0, -30, 0, 0)
        ars.switch(3)
        yield ars.current.d.deploy_time + 0.1
        hp0 = target.vitals.health + target.vitals.armor
        ars.input("left mouse down")
        held_keys["left mouse"] = 1
        yield 0.15
        self.shot("03_knife_swing")
        held_keys["left mouse"] = 0
        yield 0.2
        self.check(target.vitals.health + target.vitals.armor < hp0, "knife swing damaged target at 1.4 m")

        # ---- helmet: player headshot vs no helmet ----------------------------
        from game.combat import HEAD, compute_damage
        with_h = compute_damage(31, 10, 0.97, HEAD, 100, True, cfg.combat)[0]
        without = compute_damage(31, 10, 0.97, HEAD, 100, False, cfg.combat)[0]
        self.check(with_h < without, f"helmet: RK-9 headshot {without:.0f} -> {with_h:.0f} hp")

        # ---- F5 is ignored during LIVE -----------------------------------------
        before = tuple(p.body.pos)
        self.o["session"].handle_f5()
        yield 0.1
        self.check(rm.phase == Phase.LIVE and math.dist(before, p.body.pos) < 0.5,
                   "F5 does nothing during LIVE")

        # ================= Part B: real match flow (Phase 3) ====================
        yield from self._rounds_script(elim)

    # ------------------------------------------------------------ Phase 3
    def _rounds_script(self, elim):
        from game.rounds import ATTACKERS, DEFENDERS, FlagState, Phase
        p, bots, hud, cfg = self.o["player"], self.o["bots"], self.o["hud"], self.cfg
        rm, menu, econ = self.o["rounds"], self.o["buy_menu"], self.o["economy"]
        cfg.round.elimination_wins = elim
        orig_freeze, orig_post = cfg.round.freeze_time, cfg.flag.post_plant_time
        cfg.round.freeze_time = 6.0                  # shorter waits in the smoke test
        self.release_bots()
        rm.start_match()
        yield 0.2
        self.check(rm.phase == Phase.BUY_FREEZE and rm.round_number == 1, "new match starts in the buy phase")
        self.check(p.money == cfg.economy.start_money, f"player starts with CR {p.money}")
        self.check(rm.flag.state == FlagState.CARRIED and rm.flag.carrier in bots,
                   f"flag carried by Vanguard bot {getattr(rm.flag.carrier, 'display_name', '?')}")
        self.check(all(b.money >= 0 for b in bots) and sum("sd4" in b.owned for b in bots) == len(bots),
                   "every bot auto-bought a sidearm, nobody negative")

        # movement locked during freeze
        start = tuple(p.body.pos)
        held_keys["w"] = 1
        yield 0.6
        held_keys["w"] = 0
        self.check(math.dist(start, p.body.pos) < 0.05, "cannot leave spawn during the freeze")

        # buy menu
        menu.input("b")
        yield 0.1
        self.check(menu.is_open, "B opens the buy menu during the freeze")
        menu.input("2")                                   # SD-4
        self.check(p.money == cfg.economy.start_money - cfg.economy.sd4_price and "sd4" in p.owned,
                   f"buying the SD-4 Sidearm: CR {p.money}")
        m = p.money
        menu.input("2")
        self.check(p.money == m, "buying it again: no charge")
        menu.input("1")
        self.check(p.money == m and "rk9" not in p.owned, "RK-9 Rifle refused: not enough credits")
        yield 0.2
        self.shot("06_buy_menu")
        menu.input("b")
        self.check(not menu.is_open, "B closes the buy menu")
        before = tuple(p.body.pos)
        self.o["session"].handle_f5()
        self.check(math.dist(before, p.body.pos) > 0.5, "F5 respawns at the next spawn point during the buy phase")

        # spectate the bot rounds from a fixed spot
        def bench_player():
            p.alive = False
            p.controls_enabled = False
            self.place(18, 3.0, 16, 80, 12)

        def wait_until(cond, limit):
            t = 0.0
            while not cond() and t < limit:
                yield 0.25
                t += 0.25
            return t

        # ---- round 1: nobody shoots; carrier plants, Sentinels retake ----------
        cfg.flag.post_plant_time = 90.0              # give retakers time to cross the map
        for b in bots:
            b.hold_fire = True
        yield from wait_until(lambda: rm.phase == Phase.LIVE, 10)
        self.check(menu.is_open is False, "buy menu closed when the round went live")
        bench_player()
        yield from wait_until(lambda: rm.flag.state == FlagState.PLANTED or rm.phase != Phase.LIVE, 100)
        planted = rm.flag.state == FlagState.PLANTED
        self.check(planted, f"bot carrier planted the flag @ {rm.flag.site} "
                            f"(director chose {self.o['director'].target_site})")
        self.shot("07_planted")
        retakers = [b for b in bots if b.team == DEFENDERS and b.role.value == "retaker"]
        self.check(len(retakers) >= 1, f"{len(retakers)} Sentinel bot(s) switched to RETAKER")
        holders = [b for b in bots if b.team == ATTACKERS and b.role.value == "site_holder"]
        self.check(len(holders) >= 1, f"{len(holders)} Vanguard bot(s) holding the planted site")
        yield from wait_until(lambda: rm.phase != Phase.LIVE, 85)
        self.shot("08_round1_end")
        self.check(rm.round_winner == DEFENDERS and rm.round_reason == "takedown",
                   f"round 1: {rm.round_winner} by {rm.round_reason} (Sentinel bot took the flag down)")
        self.check(rm.score == {ATTACKERS: 0, DEFENDERS: 1}, f"score after round 1: {rm.score}")
        self.check("WINS ROUND" in hud.banner.text, f"banner: '{hud.banner.text}'")

        # ---- round 2: Sentinels frozen; the planted flag is held 25 s ---------
        cfg.flag.post_plant_time = orig_post
        yield from wait_until(lambda: rm.phase == Phase.BUY_FREEZE, 10)
        self.check(rm.round_number == 2 and rm.flag.state == FlagState.CARRIED, "round 2 reset: flag back with a carrier")
        for b in bots:
            b.frozen = b.team == DEFENDERS
        yield from wait_until(lambda: rm.phase == Phase.LIVE, 10)
        bench_player()
        yield from wait_until(lambda: rm.flag.state == FlagState.PLANTED or rm.phase != Phase.LIVE, 100)
        t_plant = rm.post_plant_left()
        self.check(t_plant is not None and abs(t_plant - orig_post) < 1.0,
                   f"round 2 planted, post-plant clock {t_plant if t_plant is None else round(t_plant, 1)} s")
        waited = yield from wait_until(lambda: rm.phase != Phase.LIVE, orig_post + 5)
        self.check(rm.round_winner == ATTACKERS and rm.round_reason == "flag_held",
                   f"round 2: {rm.round_winner} by {rm.round_reason} after ~{waited:.0f} s")
        self.check(rm.score == {ATTACKERS: 1, DEFENDERS: 1}, f"score after round 2: {rm.score}")

        # ---- round 3: free combat ---------------------------------------------
        for b in bots:
            b.frozen = False
            b.hold_fire = False
        yield from wait_until(lambda: rm.phase == Phase.LIVE, 15)
        bench_player()
        self.kills.clear()
        yield 15.0
        self.shot("09_round3_fight")
        yield from wait_until(lambda: rm.phase != Phase.LIVE, cfg.round.round_time)
        self.check(rm.phase == Phase.ROUND_END and sum(rm.score.values()) == 3,
                   f"round 3 ended: {rm.round_winner} by {rm.round_reason}, score {rm.score}")
        bot_kills = [k for k in self.kills if k[0] in bots]
        self.check(len(bot_kills) >= 1, f"bots scored {len(bot_kills)} kill(s) in round 3")
        self.check(all(b.money >= 0 for b in bots) and p.money >= 0, "nobody's money is negative")

        # ---- match end + F5 restart ----------------------------------------------
        rm.match_winner, rm.timer = DEFENDERS, 0.0
        yield 0.3
        self.check(rm.phase == Phase.MATCH_END and "WINS MATCH" in hud.banner.text,
                   f"match end banner: '{hud.banner.text}'")
        self.shot("10_match_end")
        n = rm.round_number
        yield 2.0
        self.check(rm.phase == Phase.MATCH_END and rm.round_number == n, "no rounds after match end")
        self.o["session"].handle_f5()
        yield 0.2
        self.check(rm.phase == Phase.BUY_FREEZE and rm.round_number == 1 and sum(rm.score.values()) == 0,
                   "F5 at match end starts a new match")
        cfg.round.freeze_time = orig_freeze
