"""Builds the visible Ursina scene from the pure-data map module.

All geometry is primitive cubes/planes with an original colour palette
("dusk relay": slate walls, olive-grey concrete, signal-orange accents).
"""
from __future__ import annotations

import random

from ursina import AmbientLight, DirectionalLight, Entity, Text, Vec3, color, scene, window
from ursina.shaders import lit_with_shadows_shader, unlit_shader

from game import textures
from game.maps import relay_station as M
from game.physics import CollisionWorld

# Original palette (r, g, b in 0..1)
MATERIALS = {
    "edge":      (0.26, 0.29, 0.34),
    "fill":      (0.30, 0.33, 0.39),
    "wall":      (0.45, 0.50, 0.58),
    "tower":     (0.36, 0.40, 0.50),
    "crate":     (0.22, 0.47, 0.44),
    "container": (0.60, 0.34, 0.24),
    "lowwall":   (0.52, 0.55, 0.60),
    "deck":      (0.40, 0.42, 0.40),
    "stair":     (0.47, 0.49, 0.46),
    "rail":      (0.95, 0.55, 0.15),
    "pad":       (0.38, 0.40, 0.44),
    "mast":      (0.70, 0.72, 0.76),
    "generator": (0.55, 0.52, 0.30),
    "dock":      (0.43, 0.41, 0.37),
}
FLOOR_TINT = (0.46, 0.48, 0.44)
SITE_COLORS = {"Site Alpha": (0.25, 0.85, 0.95), "Site Bravo": (0.95, 0.35, 0.75)}
SITE_LETTER = {"Site Alpha": "A", "Site Bravo": "B"}


def _rgba(rgb, a=1.0, jitter=0.0, rng=None):
    if jitter and rng:
        k = 1.0 + rng.uniform(-jitter, jitter)
        rgb = tuple(min(1.0, c * k) for c in rgb)
    return color.rgba(rgb[0], rgb[1], rgb[2], a)


class World:
    """Holds the collision world plus the visual entities."""

    def __init__(self, cfg):
        self.collision = CollisionWorld(M.collision_boxes())
        self.root = Entity(name="world")
        self.map = M
        rng = random.Random(42)

        prev_shader = Entity.default_shader
        Entity.default_shader = lit_with_shadows_shader

        # --- solids
        for s in M.SOLIDS:
            if s.material == "floor":
                continue
            b = s.box
            Entity(parent=self.root, model="cube",
                   position=((b.x0 + b.x1) / 2, (b.y0 + b.y1) / 2, (b.z0 + b.z1) / 2),
                   scale=(b.x1 - b.x0, b.y1 - b.y0, b.z1 - b.z0),
                   color=_rgba(MATERIALS.get(s.material, (0.5, 0.5, 0.5)), jitter=0.06, rng=rng))

        # --- floor (visual plane; collision comes from the floor box)
        x0, z0, x1, z1 = M.BOUNDS
        Entity(parent=self.root, model="plane",
               position=((x0 + x1) / 2, 0, (z0 + z1) / 2), scale=(x1 - x0, 1, z1 - z0),
               texture=textures.floor_tile(), texture_scale=((x1 - x0) / 2, (z1 - z0) / 2),
               color=_rgba(FLOOR_TINT))

        self._decor()

        # --- lighting
        sun = DirectionalLight(shadows=bool(cfg.graphics.sun_shadows), color=color.rgba(1.0, 0.88, 0.76, 1))
        sun.look_at(Vec3(0.55, -1.0, 0.35))
        AmbientLight(color=color.rgba(0.42, 0.45, 0.56, 1))

        Entity.default_shader = prev_shader
        self._zone_markings()

        sky = cfg.graphics.sky_color
        window.color = color.rgba(sky[0], sky[1], sky[2], 1)

    # ------------------------------------------------------------------ decor
    def _decor(self):
        """Non-colliding set dressing."""
        # Relay tower antenna + warning beacon
        Entity(parent=self.root, model="cube", position=(0, 15, 0), scale=(0.4, 6, 0.4),
               color=_rgba(MATERIALS["mast"]))
        self.beacon = Entity(parent=self.root, model="sphere", position=(0, 18.3, 0), scale=0.7,
                             color=color.rgba(1, 0.25, 0.2, 1), shader=unlit_shader)
        # Dish on Site Alpha's mast: a flattened, tilted disc
        Entity(parent=self.root, model="sphere", position=(52, 6.0, 24), scale=(4.5, 4.5, 0.5),
               rotation=(-35, -40, 0), color=_rgba((0.82, 0.84, 0.88)))
        Entity(parent=self.root, model="cube", position=(52, 5.0, 24), scale=(0.35, 1.2, 0.35),
               color=_rgba(MATERIALS["mast"]))
        # Hazard trim along the Alpha pad's west and south lips
        trim = _rgba(MATERIALS["rail"])
        Entity(parent=self.root, model="cube", position=(38.05, 1.51, 20), scale=(0.1, 0.02, 16), color=trim)
        Entity(parent=self.root, model="cube", position=(49, 1.51, 12.05), scale=(22, 0.02, 0.1), color=trim)

    def _zone_markings(self):
        hatch = textures.zone_hatch()
        for z in M.PLANT_ZONES:
            c = SITE_COLORS[z.name]
            w, d = z.x1 - z.x0, z.z1 - z.z0
            Entity(parent=self.root, model="plane", shader=unlit_shader,
                   position=((z.x0 + z.x1) / 2, z.floor_y + 0.02, (z.z0 + z.z1) / 2),
                   scale=(w, 1, d), texture=hatch, texture_scale=(w / 4, d / 4),
                   color=_rgba(c, 0.35))
            Text(parent=scene, text=SITE_LETTER[z.name], billboard=True, scale=60,
                 position=((z.x0 + z.x1) / 2, z.floor_y + 5.0, (z.z0 + z.z1) / 2),
                 origin=(0, 0), color=_rgba(c, 0.9))

    # ------------------------------------------------------------------ helpers
    def spawn(self, team: str, index: int = 0):
        pts = M.SPAWNS[team]
        x, z = pts[index % len(pts)]
        return x, z, M.SPAWN_YAW[team]

    def callout(self, x: float, z: float) -> str:
        return M.callout_at(x, z)

    def plant_zone_at(self, x: float, y: float, z: float):
        for zone in M.PLANT_ZONES:
            if zone.contains(x, z) and abs(y - zone.floor_y) < 1.0:
                return zone
        return None
