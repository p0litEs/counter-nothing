"""Headless validation for the map + movement physics (no window needed).

    python tools/check_map.py

1. Every spawn point is clear of geometry.
2. 2.5D reachability flood-fill from the attacker spawn: every key location
   (both plant sites, the other spawn, the elevated routes) must be reachable
   on foot using only walking, step-ups and drops — no jumping required.
3. Physics smoke tests: landing, wall collision, climbing stairs.
"""
from __future__ import annotations

import sys
from collections import deque
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from game.maps import relay_station as M          # noqa: E402
from game.physics import CollisionWorld, KinematicBody, accelerate  # noqa: E402
from game.settings import CFG                     # noqa: E402

P = CFG.player
CELL = 0.5
world = CollisionWorld(M.collision_boxes())
failures: list[str] = []


def check(cond: bool, msg: str) -> None:
    print(("  ok   " if cond else "  FAIL ") + msg)
    if not cond:
        failures.append(msg)


# --------------------------------------------------------------------- spawns
print("Spawns")
for team, pts in M.SPAWNS.items():
    for x, z in pts:
        body = KinematicBody(world, (x, 0.0, z), P.radius, P.stand_height, P.step_height)
        check(body.fits(x, 0.001, z), f"{team} spawn ({x}, {z}) is clear")

# --------------------------------------------------------------- reachability
print("Reachability (2.5D flood fill from attacker spawn)")
x_min, z_min, x_max, z_max = M.BOUNDS
nx = int((x_max - x_min) / CELL)
nz = int((z_max - z_min) / CELL)
r = P.radius


def surfaces(ix: int, iz: int) -> list[float]:
    """Heights a standing player could occupy at this cell."""
    cx = x_min + (ix + 0.5) * CELL
    cz = z_min + (iz + 0.5) * CELL
    col = world.query(cx - r, -2, cz - r, cx + r, 100, cz + r)
    out = []
    for h in {b.y1 for b in col}:
        if not world.query(cx - r, h + 1e-3, cz - r, cx + r, h + P.stand_height, cz + r, col):
            out.append(round(h, 3))
    return out


cache: dict[tuple[int, int], list[float]] = {}


def surf(ix, iz):
    key = (ix, iz)
    if key not in cache:
        cache[key] = surfaces(ix, iz)
    return cache[key]


def to_cell(x, z):
    return int((x - x_min) / CELL), int((z - z_min) / CELL)


start = (*to_cell(*M.SPAWNS["attackers"][0]), 0.0)
seen = {start}
queue = deque([start])
while queue:
    ix, iz, h = queue.popleft()
    for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        jx, jz = ix + dx, iz + dz
        if not (0 <= jx < nx and 0 <= jz < nz):
            continue
        for h2 in surf(jx, jz):
            if h2 - h <= P.step_height + 1e-6:          # step up, level, or drop down
                node = (jx, jz, h2)
                if node not in seen:
                    seen.add(node)
                    queue.append(node)


def reachable(x, z, h):
    ix, iz = to_cell(x, z)
    return (ix, iz, h) in seen


targets = [
    ("Site Alpha plant zone (on pad)", 48, 18, 1.5),
    ("Site Bravo plant zone", -43, 14, 0.0),
    ("Defender spawn", *M.SPAWNS["defenders"][1], 0.0),
    ("Gantry deck", 30, 16, 3.0),
    ("Overlook", 18, 16, 3.0),
    ("Bravo catwalk", -52, 26, 3.0),
    ("Loading Dock platform", -52, -15, 1.2),
    ("Cable Run", 29, -18, 0.0),
    ("Ridge Walk", 40, 36, 0.0),
    ("Back Hall", -30, 42, 0.0),
]
for name, x, z, h in targets:
    check(reachable(x, z, h), f"{name} reachable")
print(f"  ({len(seen)} reachable standing cells)")

# -------------------------------------------------------------- physics tests
print("Physics")
dt = 1.0 / CFG.movement.physics_hz


def sim(body, seconds, wish=(0.0, 0.0), speed=CFG.movement.run_speed):
    for _ in range(int(seconds / dt)):
        body.vel[1] = max(body.vel[1] - CFG.movement.gravity * dt, -CFG.movement.terminal_velocity)
        if body.grounded and wish != (0.0, 0.0):
            accelerate(body.vel, wish, speed, CFG.movement.ground_accel, dt)
        body.move(dt)


b = KinematicBody(world, (0, 3.0, -42), P.radius, P.stand_height, P.step_height)
sim(b, 1.0)
check(b.grounded and abs(b.pos[1]) < 1e-3, f"falls and lands on floor (y={b.pos[1]:.3f})")

b = KinematicBody(world, (0, 0, 30), P.radius, P.stand_height, P.step_height)
sim(b, 6.0, wish=(-1.0, 0.0))                       # walk west into the North Court west wall
check(abs(b.pos[0] - (-22 + P.radius)) < 1e-2, f"stopped flush against wall (x={b.pos[0]:.3f})")

b = KinematicBody(world, (18, 0, 3), P.radius, P.stand_height, P.step_height)
sim(b, 3.0, wish=(0.0, 1.0))                        # walk north up the Overlook stairs
check(abs(b.pos[1] - 3.0) < 1e-3, f"climbs Overlook stairs (y={b.pos[1]:.3f})")

b = KinematicBody(world, (18, 3.0, 16), P.radius, P.stand_height, P.step_height)
sim(b, 4.0, wish=(1.0, 0.0))                        # walk east across the Gantry onto the pad
check(b.pos[0] > 40 and abs(b.pos[1] - 1.5) < 1e-3,
      f"crosses Gantry and drops onto Alpha pad (x={b.pos[0]:.1f}, y={b.pos[1]:.3f})")

# ----------------------------------------------------------------- navigation
import time as _time                                  # noqa: E402

from game.nav import INF, NavGrid                     # noqa: E402

print("Bot navigation")
t0 = _time.perf_counter()
nav = NavGrid(world, M.BOUNDS, CFG.nav.cell, CFG.nav.clearance_radius,
              P.stand_height, P.step_height, CFG.nav.max_drop)
for name, pt in M.NAV_POINTS.items():
    nav.build_field(name, pt)
print(f"  ({len(nav.nodes)} nodes, {len(M.NAV_POINTS)} fields in {_time.perf_counter() - t0:.2f}s)")
for name in M.NAV_POINTS:
    f = nav.field(name)
    ok = all(f[nav.node_at(x, 0.0, z)] < INF for pts in M.SPAWNS.values() for x, z in pts)
    check(ok, f"every spawn has a path to '{name}'")

# Walk a body along the field from attacker spawn to Site Alpha using real physics.
b = KinematicBody(world, (*M.SPAWNS["attackers"][0][:1], 0.0, M.SPAWNS["attackers"][0][1]),
                  P.radius, P.stand_height, P.step_height)
field = nav.field("site_alpha")
gx, gy, gz = M.NAV_POINTS["site_alpha"]
for _ in range(int(40 / dt)):
    nid = nav.node_at(*b.pos)
    wp = nav.next_waypoint(nid, field) if nid is not None else None
    wish = (0.0, 0.0)
    if wp:
        dx, dz = wp[0] - b.pos[0], wp[2] - b.pos[2]
        m = (dx * dx + dz * dz) ** 0.5
        if m > 0.05:
            wish = (dx / m, dz / m)
    b.vel[1] = max(b.vel[1] - CFG.movement.gravity * dt, -CFG.movement.terminal_velocity)
    if b.grounded:
        from game.physics import apply_friction       # noqa: E402
        apply_friction(b.vel, dt, CFG.movement.friction, CFG.movement.stop_speed)
        accelerate(b.vel, wish, CFG.movement.run_speed, CFG.movement.ground_accel, dt)
    b.move(dt)
    if (b.pos[0] - gx) ** 2 + (b.pos[2] - gz) ** 2 < 4 and abs(b.pos[1] - gy) < 0.1:
        break
check((b.pos[0] - gx) ** 2 + (b.pos[2] - gz) ** 2 < 4,
      f"physics body follows flow field spawn -> Site Alpha (ended {b.pos[0]:.1f},{b.pos[1]:.1f},{b.pos[2]:.1f})")

# -------------------------------------------------------------- combat maths
import random as _random                              # noqa: E402

from game.combat import BODY, HEAD, CombatWorld, compute_damage, standard_hitboxes  # noqa: E402
from game.weapons import Stance, WeaponState, direction, load_definitions        # noqa: E402

print("Weapons & damage")
R = CFG.combat
defs = load_definitions(CFG)
check({d.slot for d in defs.values()} == {1, 2, 3}, "three weapons in slots 1/2/3")
check(defs["knife"].speed_multiplier == 1.25, "Field Knife speed multiplier is +25%")

hp, ar = compute_damage(30, 0, 1.0, BODY, 0, False, R)
check(abs(hp - 30) < 1e-6 and ar == 0, f"no armor: body 30 -> {hp:.1f}")
hp, ar = compute_damage(30, 0, 1.0, BODY, 100, False, R)
check(hp < 30 and ar > 0, f"armor absorbs body damage: {hp:.1f} hp, -{ar:.1f} armor")
hp_h, _ = compute_damage(30, 0, 1.0, HEAD, 100, False, R)
hp_hh, _ = compute_damage(30, 0, 1.0, HEAD, 100, True, R)
check(hp_hh < hp_h, f"helmet reduces headshot: {hp_h:.1f} -> {hp_hh:.1f}")
far, _ = compute_damage(30, 50, defs["rk9"].falloff_per_10m, BODY, 0, False, R)
check(far < 30, f"falloff at 50 m: {far:.1f}")

w = WeaponState(defs["rk9"], rng=_random.Random(1))
st_crouch, st_stand = Stance(0, True, False), Stance(0, False, False)
st_move, st_air = Stance(1.0, False, False), Stance(0.3, False, True)
order = [w.spread(s) for s in (st_crouch, st_stand, st_move, st_air)]
check(order == sorted(order), f"spread crouch<stand<move<air: {[round(o, 2) for o in order]}")
first = w.fire(st_stand)
for _ in range(9):
    w.tick(w.d.fire_interval)
    last = w.fire(st_stand)
check(last > first and w.recoil_up > 0, f"spray blooms ({first:.2f} -> {last:.2f} deg), recoil {w.recoil_up:.1f} deg up")
for _ in range(240):
    w.tick(1 / 120)
check(w.recoil_up < 0.2 and w.bloom == 0, "recoil and bloom recover after 2 s")
check(w.mag == 20, f"10 shots used: mag {w.mag}")
w.start_reload()
w.holster()
check(not w.reloading and w.mag == 20, "switching weapons cancels reload")
w.deploy()
w.start_reload()
for _ in range(int(3 / dt)):
    w.tick(dt)
check(w.mag == 30 and w.reserve == 80, f"reload fills mag from reserve ({w.mag}/{w.reserve})")


class Dummy:
    def __init__(self, x, z, team="defenders"):
        self.team, self.display_name, self.alive = team, "dummy", True
        from game.combat import Vitals
        self.vitals = Vitals(100, 0, False)
        self.p = (x, 0.0, z)

    def hitboxes(self):
        return standard_hitboxes(*self.p, P.stand_height, P.radius)

    def on_damaged(self, a, d):
        pass

    def on_killed(self, a):
        self.alive = False


cw = CombatWorld(world, R)
tgt = Dummy(0, -30)
cw.combatants.append(tgt)
hit = cw.raycast((0, 1.6, -44), direction(0, 0), 100)
check(hit is not None and hit.target is tgt and hit.part == HEAD, "ray at eye level hits head")
hit = cw.raycast((0, 1.0, -44), direction(0, 0), 100)
check(hit is not None and hit.target is tgt and hit.part == BODY, "lower ray hits body")
hit = cw.raycast((0, 1.6, -44), direction(0, 0), 100)
tgt.p = (0.0, 0.0, 30.0)                                # behind the relay tower
hit = cw.raycast((0, 1.6, -44), direction(0, 0), 100)
check(hit is not None and hit.target is None, "relay tower blocks the shot")
check(not cw.line_of_sight((0, 1.6, -44), (0, 1.6, 30)), "no line of sight through tower")

# ------------------------------------------------------- rounds / flag / money
from game.combat import Vitals                        # noqa: E402
from game.economy import Economy                      # noqa: E402
from game.rounds import ATTACKERS, DEFENDERS, FlagState, Phase, RoundManager  # noqa: E402

print("Rounds, flag & economy")
FC, RC, EC = CFG.flag, CFG.round, CFG.economy


class Actor:
    """Minimal participant for headless round tests."""

    def __init__(self, name, team, pos):
        self.display_name, self.team, self.home = name, team, pos
        self.pos, self.alive, self.is_bot = pos, True, True
        self.interact_held, self.horizontal_speed = False, 0.0
        self.money, self.owned = 0, set(EC.free_loadout)
        self.vitals = Vitals(100, 0, False)

    def feet_position(self):
        return self.pos

    def round_reset(self, idx, survived):
        self.pos, self.alive, self.interact_held, self.horizontal_speed = self.home, True, False, 0.0
        if not (survived and EC.keep_weapons_if_alive):
            self.owned = set(EC.free_loadout)
        self.vitals.health, self.vitals.armor, self.vitals.helmet = 100, 0, False


BRAVO = (-43.0, 0.0, 14.0)


def new_match():
    a1 = Actor("a1", ATTACKERS, (0.0, 0.0, -42.0))
    a2 = Actor("a2", ATTACKERS, (2.0, 0.0, -42.0))
    d1 = Actor("d1", DEFENDERS, (0.0, 0.0, 43.0))
    econ = Economy(CFG)
    rm = RoundManager(CFG, M.PLANT_ZONES, M.NAV_POINTS["attacker_spawn"], [a1, a2, d1], econ,
                      rng=_random.Random(3))
    rm.start_match()
    return rm, econ, a1, a2, d1


def run(rm, seconds, step=0.05):
    for _ in range(int(round(seconds / step))):
        rm.tick(step)


def go_live(rm):
    run(rm, RC.freeze_time + 0.05)
    assert rm.phase == Phase.LIVE, rm.phase


def plant(rm, carrier):
    rm.flag.give(carrier)
    carrier.pos, carrier.interact_held = BRAVO, True
    run(rm, FC.plant_time + 0.1)
    carrier.interact_held = False


# economy start + auto-buy
rm, econ, a1, a2, d1 = new_match()
check(rm.phase == Phase.BUY_FREEZE and rm.timer == RC.freeze_time, f"match starts in BUY_FREEZE ({RC.freeze_time:.0f} s)")
check(all(p.money >= 0 for p in (a1, a2, d1)), "bots auto-bought without going negative")
check(all("sd4" in p.owned for p in (a1, a2, d1)), f"bots with {EC.start_money} bought the SD-4 Sidearm")
check(rm.flag.state == FlagState.CARRIED and rm.flag.carrier.team == ATTACKERS, "a Vanguard bot carries the flag at round start")
check(rm.movement_locked and rm.buy_open, "freeze locks movement and opens buying")

# plant timer
go_live(rm)
rm.flag.give(a1)
a1.pos, a1.interact_held = BRAVO, True
run(rm, FC.plant_time - 0.2)
check(rm.flag.state == FlagState.CARRIED, f"not planted after {FC.plant_time - 0.2:.1f} s")
run(rm, 0.3)
check(rm.flag.state == FlagState.PLANTED and rm.flag.site == "Site Bravo",
      f"planted at Site Bravo after {FC.plant_time:.1f} s")
check(abs(rm.timer - FC.post_plant_time) < 0.2, f"post-plant timer started at {rm.timer:.1f} s")

# takedown with interruptions
a1.interact_held = False
d1.pos, d1.interact_held = (BRAVO[0] + 1.0, 0.0, BRAVO[2]), True
run(rm, 4.0)
check(abs(rm.progress_for(d1)[1] - 4.0 / FC.takedown_time) < 0.03, "takedown progress 4/5 s")
d1.horizontal_speed = FC.interrupt_speed + 1
run(rm, 0.05)
d1.horizontal_speed = 0.0
check(rm.progress_for(d1)[1] == 0.0, "moving resets takedown progress to 0")
run(rm, 3.0)
rm.on_damaged(d1)
run(rm, 0.05)
check(rm.progress_for(d1)[1] == 0.0, "taking damage resets takedown progress to 0")
d1.interact_held = False
run(rm, 0.05)
check(rm.progress_for(d1) is None, "releasing E cancels the takedown")
d1.interact_held = True
run(rm, FC.takedown_time + 0.1)
check(rm.phase == Phase.ROUND_END and rm.round_winner == DEFENDERS and rm.round_reason == "takedown",
      "completed takedown -> Sentinel wins the round")
check(rm.score == {ATTACKERS: 0, DEFENDERS: 1}, f"score {rm.score}")

# post-plant expiry
rm, econ, a1, a2, d1 = new_match()
go_live(rm)
plant(rm, a1)
run(rm, FC.post_plant_time - 0.5)
check(rm.phase == Phase.LIVE, "flag still ticking just before post-plant expiry")
run(rm, 0.6)
check(rm.round_winner == ATTACKERS and rm.round_reason == "flag_held",
      f"post-plant {FC.post_plant_time:.0f} s expiry -> Vanguard wins")

# round time expiry pre-plant
rm, econ, a1, a2, d1 = new_match()
go_live(rm)
run(rm, RC.round_time + 0.1)
check(rm.round_winner == DEFENDERS and rm.round_reason == "time",
      f"round timer {RC.round_time:.0f} s expires pre-plant -> Sentinel wins")

# flag drop / pickup / return
rm, econ, a1, a2, d1 = new_match()
go_live(rm)
rm.flag.give(a1)
a1.pos = (10.0, 0.0, -20.0)
a1.alive = False
rm.on_kill(d1, a1)
check(rm.flag.state == FlagState.DROPPED and rm.flag.pos == (10.0, 0.0, -20.0), "carrier death drops the flag")
a2.pos = (10.0 + FC.pickup_radius - 0.2, 0.0, -20.0)
run(rm, 0.05)
check(rm.flag.state == FlagState.CARRIED and rm.flag.carrier is a2, "teammate walking over picks it up")
a2.alive = False
rm.on_kill(None, a2)
a1.alive = True
a1.pos = (0.0, 0.0, 0.0)
run(rm, FC.flag_return_time + 0.1)
check(rm.flag.at_home and rm.flag.pos == tuple(M.NAV_POINTS["attacker_spawn"]),
      f"untouched flag returns home after {FC.flag_return_time:.0f} s")

# first to N + match end stops progression
rm, econ, a1, a2, d1 = new_match()
for _ in range(CFG.match.rounds_to_win):
    go_live(rm)
    run(rm, RC.round_time + 0.1)
    run(rm, RC.round_end_delay + 0.1)
check(rm.phase == Phase.MATCH_END and rm.match_winner == DEFENDERS,
      f"first to {CFG.match.rounds_to_win} ends the match ({rm.score})")
n = rm.round_number
run(rm, 60)
check(rm.phase == Phase.MATCH_END and rm.round_number == n, "no more rounds after match end")

# economy arithmetic
rm, econ, a1, a2, d1 = new_match()
for p in (a1, a2, d1):
    p.money = EC.start_money
econ.start_match([a1, a2, d1])
check(a1.money == EC.start_money, f"start money {EC.start_money}")
econ.on_kill(a1, d1)
check(a1.money == EC.start_money + EC.kill_reward, f"kill reward +{EC.kill_reward} credited to killer")
econ.on_kill(a1, a2)
check(a1.money == EC.start_money + EC.kill_reward, "no reward for a teammate kill")
expected = []
for i in range(3):
    before = a1.money
    econ.on_round_end(DEFENDERS, [a1, a2, d1])
    expected.append(a1.money - before)
ladder = EC.loss_bonus_ladder
check(expected == ladder[:3], f"loss bonus ladder advances: {expected}")
before_d = d1.money
econ.on_round_end(ATTACKERS, [a1, a2, d1])
check(econ.loss_streak[ATTACKERS] == 0 and econ.loss_streak[DEFENDERS] == 1, "a win resets the streak")
check(d1.money - before_d == ladder[0], "the other side's streak restarts at the first rung")
a1.money = 100
r = econ.purchase(a1, "rk9")
check(r == "poor" and a1.money == 100, "cannot buy what you can't afford; money unchanged")
a1.money = 5000
econ.purchase(a1, "rk9")
m = a1.money
check(econ.purchase(a1, "rk9") == "owned" and a1.money == m, "buying an owned item: no charge")
a1.money = EC.max_money - 10
econ.on_kill(a1, d1)
check(a1.money == EC.max_money, f"money capped at {EC.max_money}")
check(all(p.money >= 0 for p in (a1, a2, d1)), "money never negative")

print()
if failures:
    print(f"{len(failures)} check(s) FAILED")
    sys.exit(1)
print("All map/physics checks passed.")
